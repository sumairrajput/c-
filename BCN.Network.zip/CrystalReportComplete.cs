﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Microsoft.ReportingServices.Diagnostics;
using Stock;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class CrystalReportComplete : Form
    {
        ReportDocument cryrpt = new ReportDocument();

        public CrystalReportComplete()
        {
            InitializeComponent();
        }
        DataTable dst = new DataTable();
        private void CrystalReportComplete_Load(object sender, EventArgs e)
        {
            //cryrpt.Load(@"D:\VS\New folder (2)\BCN.Network\BCN.Network\Reports\CrystalReportOrderItems.rpt");

            //SqlConnection con = Connection.GetConnection();
            //con.Open();

            //SqlCommand sda = new SqlCommand("Select * From [OrderItems]  ", con);
            //SqlCommand sda1 = new SqlCommand("Select * From  Orders ", con);
            //sda.ExecuteReader();
            //con.Close();

            ////SqlCommand sda = new SqlCommand("Select * From [OrderItems]  ", con);
            //SqlCommand sda = new SqlCommand("Select * From [OrderItems], [Orders] ", con);

            ////con.Open();
            //SqlDataReader reader = sda.ExecuteReader();

            //dst.Load(reader);

            //sda.Fill(dst, "OrderItems");
            //sda1.Fill(dst, "Orders");
            //cryrpt.SetDataSource(dst);
            //con.Close();

            //crystalReportViewer.ReportSource = cryrpt;
            //cryrpt.Load(@"D:\VS\New folder (2)\BCN.Network\BCN.Network\Reports\CrystalReportOrderItems.rpt");

            //SqlConnection con = Connection.GetConnection();


            //SqlCommand sda = new SqlCommand("Select * From [OrderItems] ", con);
            //con.Open();
            //SqlDataReader reader = sda.ExecuteReader();

            //dst.Load(reader);
            //con.Close();

            //cryrpt.SetDataSource(dst);
            //crystalReportViewer.ReportSource = cryrpt;

            cryrpt.Load(@"D:\VS\New folder (2)\BCN.Network\BCN.Network\Reports\CrystalReportOrderItems.rpt");

            SqlConnection con = Connection.GetConnection();
            con.Open();
            SqlCommand sda = new SqlCommand("Select * From [OrderItems] ", con);
            SqlDataReader reader = sda.ExecuteReader();

            dst.Load(reader);
            con.Close();

            crystalReportViewer.ReportSource = cryrpt;
        }

       
    }
}
