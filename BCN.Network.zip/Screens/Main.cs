﻿using BCN.Network.Screens.Templetes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using BCN.Network.Models;

namespace BCN.Network.Screens
{
    public partial class Main : MainThemeForm
    {
        public Main()
        {
            InitializeComponent();
        }



        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void closelbl_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            isauthenticate();
            
        }

        private bool isauthenticate()
        {

            if (isValidated())
            {



                string connString = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    using (SqlCommand cmd = new SqlCommand("Select * from [Login] where UName='" + this.textBox1.Text + "' and Pwd='" + this.textBox2.Text + "';", conn))

                    {
                        conn.Open();
                        SqlDataReader rede;
                        rede = cmd.ExecuteReader();

                        int count = 0;

                        while (rede.Read())
                        {

                            count = count + 1;
                        }
                        if (count == 1)
                        {
                            LoginInUser.UName = textBox1.Text;

                            //MessageBox.Show("username and password is correct...Successful", "Microsoft Visual Studio Community 2017", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            this.Hide();
                            BankMain obj = new BankMain();
                            obj.ShowDialog();

                        }
                        else
                        {


                            MessageBox.Show("Sorry...Try again,Invalid e-mail and password!", "Microsoft Visual Studio Community 2017", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            textBox1.Clear();
                            textBox2.Clear();
                            textBox1.Select();

                        }


                        conn.Close();
                    }
                }
            }
            return true;
        }
          
        
        private bool isValidated()
        {
            if (textBox1.Text.Trim() == string.Empty)
            {
                lblname.Visible = true;
                textBox1.Clear();
                textBox1.Focus();
                return false;
            }
            else
            { 
                lblname.Visible = false;

                textBox2.Focus();
            }

            if (textBox2.Text.Trim() == string.Empty)
            {
                lblpwd.Visible = true;
                textBox2.Clear();
                textBox2.Focus();
                return false;
            }
            else
            { 
                lblpwd.Visible = false;
                button1.Focus();
            }


            return true;
        }


        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == string.Empty)
            {
                lblname.Visible = true;
                textBox1.Focus();
            }
            else
            {
                lblname.Visible = false;
                textBox2.Focus();
            }
        }


        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text.Trim() == string.Empty)
            {
                lblpwd.Visible = true;
                textBox2.Focus();
            }
            else
            {
                lblpwd.Visible = false;
                button1.Focus();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
              


                isauthenticate();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
             
                isauthenticate();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            //this.Hide();
            ForgotPassword obj = new ForgotPassword();
            obj.ShowDialog();
        }
    }
}
