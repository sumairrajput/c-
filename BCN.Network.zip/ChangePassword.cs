﻿using BCN.Network.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IsValidated())
            {
                try
                {
                    Updatepassword();
                    MessageBox.Show("Password change successfully!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();

                }
                catch (ApplicationException ex)
                {

                    MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


                }
            }
        }

        private void Updatepassword()
        {
            string connString = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
            string cmdString = "update Login set [Pwd]=@Pwd where UName=@UName";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand(cmdString , conn))

                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@UName", LoginInUser.UName);
                         cmd.Parameters.AddWithValue("@Pwd", textBox3.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
            }
                }

        private bool IsValidated()
        {
            if (textBox3.Text.Trim() == string.Empty)
            {
                MessageBox.Show("New password is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox3.Clear();
                textBox3.Focus();

                return false;
            }
            if (textBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Re-type password is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox2.Clear();
                textBox2.Focus();

                return false;
            }
            if (textBox3.Text.Trim() != textBox2.Text.Trim())
            {
                MessageBox.Show("Password doesn't match!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Clear();
                textBox2.Focus();

                return false;
            }






            return true;
        }

        private void closelbl_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
