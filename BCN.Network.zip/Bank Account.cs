﻿using BCN.Network.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class Bank_Account : Form
    {
        public Bank_Account()
        {
            InitializeComponent();
        }
        // Order Number
        public string OrderNumber { get; set; }

        // Is Update
        public bool IsUpdate { get; set; }
        public enum PaymentCreditorDeposit
        {
            Credit = 1,
            Deposit = 0
        }
   
      
        decimal TotalMinus;

        private void AddItemGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private bool IsValidated()
        {
            if (txtBoxCustomerName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Client Name is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBoxCustomerName.Clear();
                txtBoxCustomerName.Focus();

                return false;
            }
            if (txtBoxMobileNo.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Mobile number is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBoxMobileNo.Clear();
                txtBoxMobileNo.Focus();

                return false;
            }
            if (ComboBoxAccountName.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Account name here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ComboBoxAccountName.Focus();
                return false;
            }

            if (textBoxAdd.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Amount is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxAdd.Focus();
                return false;
            }
            else
            {
                decimal n;
                bool isDecimal = decimal.TryParse(textBoxAdd.Text.Trim(), out n);

                if (!isDecimal)
                {
                    MessageBox.Show("Amount should be decimal value!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxAdd.Clear();
                    textBoxAdd.Focus();
                    return false;
                }
            }
            



            return true;
        }

        private bool CheckIfOrderNumberExists(string orderNumber)
        {
            bool doesOrderNumberExist = false;

            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Orders WHERE [OrderNumber]=@OrderNumber", conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@OrderNumber", orderNumber);

                    DataTable dtAnyData = new DataTable();

                    SqlDataReader reader = cmd.ExecuteReader();

                    dtAnyData.Load(reader);

                    if (dtAnyData.Rows.Count > 0)
                    {
                        doesOrderNumberExist = true;
                    }

                }
            }

            return doesOrderNumberExist;

        }

        private string GenerateOrderNumber()
        {
            string orderNumber;

            // JI-XXXXXXXXX-XXXX
            Random rnd = new Random();
            long orderpart1 = rnd.Next(100000, 9999999);
            int orderpart2 = rnd.Next(1000, 9999);

            orderNumber = "BA-" + orderpart1 + "-" + orderpart2;

            return orderNumber;
        }

        private void AddNewOrderbtn_Click(object sender, EventArgs e)
        {
            string orderNumber;
            bool isOrderNumAlreadyExist = true;

            while (isOrderNumAlreadyExist)
            {
                orderNumber = GenerateOrderNumber();

                isOrderNumAlreadyExist = CheckIfOrderNumberExists(orderNumber);

                txtBoxOrderId.Text = orderNumber;
            }
            AddNewOrderbtn.Enabled = false;

            cancleOrderBtn.Enabled = true;
            printOrderBtn.Enabled = true;
            AddItemGroupBox.Enabled = true;
            comboBox.Enabled = false;

            txtBoxCustomerName.Focus();
        }

        private void Bank_Account_Load(object sender, EventArgs e)
        {
            
            LoadDataIntoComboBoxes();
            AddNewOrderbtn.Enabled = true;
           
            printOrderBtn.Enabled = false;
            cancleOrderBtn.Enabled = false;
           
            AddItemGroupBox.Enabled = false;
        }

        private void ComboBoxAccountName_SelectedValueChanged(object sender, EventArgs e)
        {
            if (ComboBoxAccountName.SelectedValue != null)
            {
                int itemId = Convert.ToInt16(ComboBoxAccountName.SelectedValue);
                DataTable dtItemPrice = GetItemDetails(itemId);
                DataRow row = dtItemPrice.Rows[0];

               
                textBoxTotalAmount.Text = row["TotalBalance"].ToString();
                //textBox2.Text = row["ID"].ToString();
                textBox1.Text = row["TotalBalance"].ToString();
                comboBox.Enabled = true;

            }
        }
        private void LoadDataIntoComboBoxes()
        {
            LoadDataIntoProductsComboBox();
        }

        private void LoadDataIntoProductsComboBox()
        {
            ComboBoxAccountName.SelectedValueChanged -= ComboBoxAccountName_SelectedValueChanged;

            ComboBoxAccountName.DataSource = GetProductsName();
            ComboBoxAccountName.DisplayMember = "AccountName";
            ComboBoxAccountName.ValueMember = "ID";

            ComboBoxAccountName.SelectedIndex = -1;

            ComboBoxAccountName.SelectedValueChanged += ComboBoxAccountName_SelectedValueChanged;
        }

        private DataTable GetProductsName()
        {
            DataTable dtProducts = new DataTable();

            string connString = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                //using (SqlCommand cmd = new SqlCommand("SELECT  itemName,itemPrice,itemQuentity,khaliBori,itemTotalPrice FROM DataEntered", conn))
                using (SqlCommand cmd = new SqlCommand("SELECT  ID,AccountName FROM BankAccount", conn))

                {
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    dtProducts.Load(reader);
                }
            }

            return dtProducts;
        }
        private DataTable GetItemDetails(int itemId)
        {
            DataTable dtItemDetails = new DataTable();
            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                //using (SqlCommand cmd = new SqlCommand("SELECT AccountName,AccountCreateDate,TotalBalance FROM BankAccount WHERE ID=@Id", conn))
                //using (SqlCommand cmd = new SqlCommand("SELECT ID,AccountName,TotalBalance FROM BankAccount WHERE ID=@Id", conn))
                using (SqlCommand cmd = new SqlCommand("SELECT AccountName,TotalBalance FROM BankAccount WHERE ID=@Id", conn))

                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@Id", itemId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    dtItemDetails.Load(reader);

                }
            }
            return dtItemDetails;
        }







        private void cancleOrderBtn_Click(object sender, EventArgs e)
        {
            AddNewOrderbtn.Enabled = true;
            cancleOrderBtn.Enabled = false;
            printOrderBtn.Enabled = false;
            paidBtn.Enabled = false;
            unPaidBtn.Enabled = false;
            AddItemGroupBox.Enabled = false;
            txtBoxCustomerName.Clear();
            txtBoxMobileNo.Clear();
            txtBoxOrderId.Clear();
            dateTimePickerCustomer.Text = "";
            ComboBoxAccountName.SelectedIndex = -1;
            comboBox.SelectedIndex = -1;
            textBoxAdd.Clear();
            textBoxTotalAmount.Clear();
        }

     

       

       

    

      

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox.Text == "Credit")
            {
                paidBtn.Enabled = true;
                unPaidBtn.Enabled = false;
                textBoxTotalAmount.Text = textBox1.Text;
                textBoxAdd.Clear();
               
                
            }
            else if (comboBox.Text == "Deposit")
            {
                paidBtn.Enabled = false;
                unPaidBtn.Enabled = true;
                textBoxTotalAmount.Text = textBox1.Text;
                textBoxAdd.Clear();



            }
        }

        private void textBoxAdd_TextChanged(object sender, EventArgs e)
        {
            try
            {


                if (comboBox.Text == "Credit")
                {

                    if (textBoxAdd.Text.Trim() == string.Empty)
                    {


                        textBoxTotalAmount.Text = textBox1.Text;


                    }

                    else if (textBoxAdd.Text.Trim() == "0")
                    {

                        TotalMinus = (Convert.ToDecimal(textBoxAdd.Text) + Convert.ToDecimal(textBox1.Text));
                        textBoxTotalAmount.Text = TotalMinus.ToString();

                    }
                    else if (textBoxAdd.Text.Length > 0)
                    {

                        TotalMinus = (Convert.ToDecimal(textBoxAdd.Text) + Convert.ToDecimal(textBox1.Text));

                        textBoxTotalAmount.Text = TotalMinus.ToString();

                    }
                }
                else if (comboBox.Text == "Deposit")
                {

                    if (textBoxAdd.Text.Trim() == string.Empty)
                    {


                        textBoxTotalAmount.Text = textBox1.Text;


                    }

                    else if (textBoxAdd.Text.Trim() == "0")
                    {

                        TotalMinus = (Convert.ToDecimal(textBox1.Text) - Convert.ToDecimal(textBoxAdd.Text));
                        textBoxTotalAmount.Text = TotalMinus.ToString();

                    }
                    else if (textBoxAdd.Text.Length > 0)
                    {

                        TotalMinus = (Convert.ToDecimal(textBox1.Text) - Convert.ToDecimal(textBoxAdd.Text));

                        textBoxTotalAmount.Text = TotalMinus.ToString();

                    }
                }
                else
                {

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
        }

        private void paidBtn_Click(object sender, EventArgs e)
        {
            SaveOrder();
        }

        private void SaveOrder()
        {
            if (IsValidated())
            {

            
                SqlTransaction trans = null;
            try
            {
                string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connstring))
                {
                    conn.Open();

                    trans = conn.BeginTransaction();

                    using (SqlCommand cmd = new SqlCommand("UPDATE [BankAccount] SET TotalBalance=@TotalBalance WHERE AccountName=@AccountName ", conn))
                    {
                        cmd.Transaction = trans;

                        cmd.Parameters.AddWithValue("@AccountName", Convert.ToString(ComboBoxAccountName.Text));
                        cmd.Parameters.AddWithValue("@TotalBalance", Convert.ToInt16(textBoxTotalAmount.Text));


                        cmd.ExecuteNonQuery();

                    }

                    using (SqlCommand cmd = new SqlCommand("INSERT INTO [BankAccountDetails]([Check Number],[Account Name],[Transaction Date],[Client Name],[Mobile],[CreditorDeposit],[Amount],[Total Balance]) VALUES(@CheckNumber,@AccountName,@TransactionDate,@ClientName,@Mobile,@CreditorDeposit,@Amount,@TotalBalance)", conn))
                    {
                        cmd.Transaction = trans;

                        cmd.Parameters.AddWithValue("@CheckNumber", txtBoxOrderId.Text);
                            cmd.Parameters.AddWithValue("@AccountName", ComboBoxAccountName.Text);

                            cmd.Parameters.AddWithValue("@TransactionDate", dateTimePickerCustomer.Value.Date);
                        cmd.Parameters.AddWithValue("@ClientName", txtBoxCustomerName.Text);
                        cmd.Parameters.AddWithValue("@Mobile", txtBoxMobileNo.Text);
                        cmd.Parameters.AddWithValue("@CreditorDeposit", (comboBox.Text));
                        cmd.Parameters.AddWithValue("@Amount", (textBoxAdd.Text));
                        
                        cmd.Parameters.AddWithValue("@TotalBalance", (textBoxTotalAmount.Text));
                        cmd.ExecuteNonQuery();

                    }


                  

                    //Commit the transacation
                    trans.Commit();
                    MessageBox.Show("Order is processed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // Clear screen for next order
                        ClearScreenForNextOrder();

                    }
            }

            catch (Exception ex)
            {
                trans.Rollback();
                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            }
        }

        private void ClearScreenForNextOrder()
        {
            AddNewOrderbtn.Enabled = true;
            cancleOrderBtn.Enabled = false;
            printOrderBtn.Enabled = false;
            paidBtn.Enabled = false;
            unPaidBtn.Enabled = false;
            AddItemGroupBox.Enabled = false;
            txtBoxCustomerName.Clear();
            txtBoxMobileNo.Clear();
            txtBoxOrderId.Clear();
            dateTimePickerCustomer.Text = "";
            ComboBoxAccountName.SelectedIndex = -1;
            comboBox.SelectedIndex = -1;
            textBoxAdd.Clear();
            textBoxTotalAmount.Clear();
        }

        private void unPaidBtn_Click(object sender, EventArgs e)
        {
            SaveOrder();

        }

        private void txtBoxMobileNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtBoxCustomerName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetterOrDigit(e.KeyChar)) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void printOrderBtn_Click(object sender, EventArgs e)
        {
            PrintDocument.Print();
        }

        private void PrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //Image image = Properties.Resources.logo2;
            //نام تعداد قیمت کل قیمت
            e.Graphics.DrawString("Bismillah Keryana Store", new Font("Georgia", 24, FontStyle.Bold), Brushes.Chocolate, new Point(200, 15));
            e.Graphics.DrawString("Address:", new Font("Georgia", 24, FontStyle.Bold), Brushes.Chocolate, new Point(25, 75));


            e.Graphics.DrawString("Saifa abad no 1", new Font("Calibri", 24, FontStyle.Bold), Brushes.Chocolate, new Point(200, 75));
            e.Graphics.DrawString("Ph No:", new Font("Georgia", 24, FontStyle.Bold), Brushes.Chocolate, new Point(25, 105));

            e.Graphics.DrawString("03059761589", new Font("Calibri", 24, FontStyle.Bold), Brushes.Chocolate, new Point(200, 105));
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------------------------", new Font("Georgia", 24, FontStyle.Bold), Brushes.Black, new Point(-11, 135));



            e.Graphics.DrawString("Date: " + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(600, 160));
            e.Graphics.DrawString("Check Id: " + txtBoxOrderId.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 160));
            e.Graphics.DrawString("Client Name: " + txtBoxCustomerName.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 180));
            e.Graphics.DrawString("Mobile No: " + txtBoxMobileNo.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(600, 180));

            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 235));
            e.Graphics.DrawString("Account Name", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(30, 255));
            e.Graphics.DrawString( ComboBoxAccountName.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(30, 285));

            e.Graphics.DrawString("CreditorDeposit", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(380, 255));
            e.Graphics.DrawString( comboBox.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(380, 285));

            e.Graphics.DrawString("Amount" , new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(570, 255));
            e.Graphics.DrawString( textBoxAdd.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(570, 285));

            e.Graphics.DrawString("Total Balance" , new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(677, 255));
            e.Graphics.DrawString(  textBoxTotalAmount.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(677, 285));


            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 270));


        }

        private void PrintPreviewDialog_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog.Document = PrintDocument;
            PrintPreviewDialog.ShowDialog();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtBoxCustomerName.Text = "Sumair";
                txtBoxMobileNo.Text = "03059761589";
            }
            else
            {
                txtBoxCustomerName.Clear();
                txtBoxMobileNo.Clear();
            }
        }
    }

}
