﻿//using CrystalDecisions.CrystalReports.Engine;
//using Microsoft.ReportingServices.Diagnostics.Internal;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Data.SqlClient;
//using System.Drawing;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Microsoft.ReportingServices.Diagnostics;
using Stock;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class crystalreportForm : Form
    {
        ReportDocument cryrpt = new ReportDocument();

        public crystalreportForm()
        {
            InitializeComponent();
        }

       



       
        DataSet dst = new DataSet();

        private void AddNewOrderbtn_Click(object sender, EventArgs e)
        {
            cryrpt.Load(@"D:\VS\New folder (2)\BCN.Network\BCN.Network\Reports\CrystalReportOrderItems.rpt");
            //string appPath = Application.StartupPath;
            //string reportPath = @"Reports\CrystalReportOrderItems.rpt";
            //string reportFullPath = Path.Combine(appPath, reportPath);

            //cryrpt.Load(reportFullPath);
            //cryrpt.Load(Application.StartupPath + "CrystalReportOrderItems.rpt");

            SqlConnection con = Connection.GetConnection();
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("Select * From [OrderItems]  where Cast( TranscationDate as Date) between '" + dateTimePickerCustomer.Value.ToString("MM/dd/yyyy") + "' and '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'", con);
            SqlDataAdapter sda1 = new SqlDataAdapter("Select * From  [Orders] where Cast( TransactionDate as Date) between '" + dateTimePickerCustomer.Value.ToString("MM/dd/yyyy") + "' and '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'", con);

            sda.Fill(dst, "OrderItems");
            sda1.Fill(dst, "Orders");

            cryrpt.SetDataSource(dst);
            cryrpt.SetParameterValue("@FromDate", dateTimePickerCustomer.Value.ToString("dd/MM/yyyy"));
            cryrpt.SetParameterValue("@ToDate", dateTimePicker1.Value.ToString("dd/MM/yyyy"));
            crystalReportViewer.ReportSource = cryrpt;
        }

      

       

      

       



      

        private void label2_Click(object sender, EventArgs e)
        {
            crystalreportForm obj = new crystalreportForm();
            obj.ShowDialog();
            this.Hide();

        }

        private void crystalreportForm_Load(object sender, EventArgs e)
        {

        }
    }
}
