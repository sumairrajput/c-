﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace BCN.Network
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();
        }
        decimal TotalCalc;
        void reset()
        {
            textBoxID.Text = "";
            textBoxExtraQuantity.Text = "";
            txtBoxName.Text = "";
            comboBoxUnit.Text = "Select Unit";
            dateTimePicker.Text = "";
            txtBoxTotalPrice.Text = "";
            txtBoxSearch.Text = "";
            txtBoxExtra.Text = "";
            txtBoxPrice.Text = "";
            txtBoxQuantity.Text = "";
            dateTimePicker.Enabled = false;
            textBoxID.Enabled = false;
            txtBoxName.Enabled = false;
            textBoxExtraQuantity.Enabled = false;
            txtBoxPrice.Enabled = false;
            comboBoxUnit.Enabled = false;
            txtBoxQuantity.Enabled = false;
            txtBoxExtra.Enabled = false;




        }

        private void txtBoxSearch_TextChanged(object sender, EventArgs e)
        {

            try
            {
                  if (txtBoxSearch.Text == "")
                {
                    reset();
                    txtBoxSearch.Focus();

                }
                  else
                { 
                string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
                using (SqlConnection cnn = new SqlConnection(st))
                {

                    SqlCommand cmm = new SqlCommand("select * from DataEntered where  itemName=@find", cnn);
                    cnn.Open();
                    SqlDataReader rdr;
                    cmm.Parameters.Add("@find", SqlDbType.VarChar, 50, "itemName");
                    cmm.Parameters["@find"].Value = txtBoxSearch.Text;
                    rdr = cmm.ExecuteReader();
                    while (rdr.Read())

                    {
                            textBoxID.Text = rdr[0].ToString();
                            dateTimePicker.Text = rdr[1].ToString();
                            txtBoxName.Text = rdr[2].ToString();
                        txtBoxPrice.Text = rdr[3].ToString();
                        comboBoxUnit.Text = rdr[4].ToString();
                        txtBoxQuantity.Text = rdr[5].ToString();
                            textBoxExtraQuantity.Text = rdr[6].ToString();

                            txtBoxExtra.Text = rdr[7].ToString();
                        txtBoxTotalPrice.Text = rdr[8].ToString();

                            txtBoxName.Enabled = true;
                            dateTimePicker.Enabled = true;
                            txtBoxPrice.Enabled = true;
                            comboBoxUnit.Enabled = true;
                            txtBoxQuantity.Enabled = true;
                            textBoxExtraQuantity.Enabled = true;
                            txtBoxExtra.Enabled = true;

                        }
                    cnn.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       
        private void resetBtn_Click(object sender, EventArgs e)
        {
            reset();
            txtBoxSearch.Focus();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBoxSearch.Text == "")
                {
                    MessageBox.Show("No Item found here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtBoxSearch.Focus();

                }



                else if (txtBoxName.Text == "")
                {
                    MessageBox.Show("Please enter  Name here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtBoxName.Focus();
                }
                else if (txtBoxPrice.Text == "")
                {
                    MessageBox.Show("Please enter Price here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtBoxPrice.Focus();
                }

                else if (comboBoxUnit.Text == "Select Unit")
                {
                    MessageBox.Show("Please select Unit here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    comboBoxUnit.Focus();
                }
                else if (txtBoxQuantity.Text == "")
                {
                    MessageBox.Show("Please enter Quantity here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtBoxQuantity.Focus();
                }
                else if (textBoxExtraQuantity.Text == "")
                {
                    MessageBox.Show("Please enter Khali Bori Quantity here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    textBoxExtraQuantity.Focus();
                }
                else if (txtBoxExtra.Text == "")
                {
                    MessageBox.Show("Please enter Extra Charges here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtBoxExtra.Focus();
                }


                else
                {
                    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
                    using (SqlConnection cnn = new SqlConnection(st))
                    {
                        SqlCommand cmm = new SqlCommand("update DataEntered  set itemName='" + txtBoxName.Text + "',entryDate='" + dateTimePicker.Text + "', itemPrice='" + txtBoxPrice.Text + "',itemUnit='" + comboBoxUnit.Text + "',itemQuentity='" + txtBoxQuantity.Text + "',khaliBoriPrice='" + txtBoxExtra.Text + "',khaliBoriQuantity='" + textBoxExtraQuantity.Text + "',itemTotalPrice='" + txtBoxTotalPrice.Text + "' where ID='" + textBoxID.Text + "';", cnn);

                        cnn.Open();


                        cmm.ExecuteNonQuery();
                        MessageBox.Show("Value is Updated...Successful!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        cnn.Close();
                        reset();
                        txtBoxSearch.Focus();
                    }

                }
            }

            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
        }

      

     

       

       

        private void Update_Load(object sender, EventArgs e)
        {
            txtBoxName.Enabled = false;
            dateTimePicker.Enabled = false;
            txtBoxPrice.Enabled = false;
            comboBoxUnit.Enabled = false;
            txtBoxQuantity.Enabled = false;
            textBoxExtraQuantity.Enabled = false;
            txtBoxExtra.Enabled = false;

        }





        private void txtBoxPrice_TextChanged(object sender, EventArgs e)
        {


            AllCalc();
        }
        private void AllCalc()
        {
            try
            {
                if (txtBoxPrice.Text.Trim() == string.Empty)
                {

                    txtBoxTotalPrice.Text = "";

                }
                else if (txtBoxQuantity.Text.Trim() == string.Empty)
                {


                    txtBoxTotalPrice.Text = "";



                }
                else if (textBoxExtraQuantity.Text.Trim() == string.Empty)
                {
                    txtBoxTotalPrice.Text = "";

                }
                else if (txtBoxExtra.Text.Trim() == string.Empty)
                {
                    txtBoxTotalPrice.Text = "";

                }
                else if (txtBoxPrice.Text.Trim() == "0")
                {


                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }

                else if (txtBoxQuantity.Text.Trim() == "0")
                {

                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();

                }
                else if (textBoxExtraQuantity.Text.Trim() == "0")
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();


                }
                else if (txtBoxExtra.Text.Trim() == "0")
                {


                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (txtBoxPrice.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (txtBoxQuantity.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (textBoxExtraQuantity.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (txtBoxExtra.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }



        }

        private void txtBoxQuantity_TextChanged(object sender, EventArgs e)
        {
            AllCalc();




        }



        private void txtBoxExtra_TextChanged(object sender, EventArgs e)
        {
            AllCalc();
          


        }





        private void txtBoxSearchNameCode(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetterOrDigit(e.KeyChar)) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }



     

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBoxSearch.Text == "")
                {
                    MessageBox.Show("No Item found here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtBoxSearch.Focus();

                } else
                {
                    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
                    using (SqlConnection cnn = new SqlConnection(st))
                    {
                        SqlCommand cmm = new SqlCommand("delete  from DataEntered   where  itemName='" + txtBoxName.Text + "';", cnn);

                        cnn.Open();


                        cmm.ExecuteNonQuery();
                        MessageBox.Show("Value is Deleted...Successfully!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        cnn.Close();
                        reset();
                        txtBoxSearch.Focus();
                    }

                }
            }

            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
        }

        private void PirceQuantityExtra(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }




     

      

        private void textBoxExtraQuantity_TextChanged(object sender, EventArgs e)
        {
            AllCalc();
        }
    }
}
   
  
    

