﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using BCN.Network.Models;
using System.Data.SqlClient;

namespace BCN.Network
{
    public partial class PrintOrder : Form
    {
        public PrintOrder()
        {
            InitializeComponent();
        }
       
      
        // Order Number
        public string OrderNumber { get; set; }

        // Is Update
        public bool IsUpdate { get; set; }
        public enum PaymentGivenorNot
        {
            Paid = 1,
            UnPaid = 0
        }
        private List<CartItemNames> shoppingCart = new List<CartItemNames>();
        private int numberOfItemsPerPage = 0;
        private int numberOfItemsPrintedSoFar = 0;
        decimal TotalMinus;

       
        
        private void PrintOrder_Load(object sender, EventArgs e)
        {
           
            LoadDataIntoComboBoxes();

            if (this.IsUpdate)
            {
                LoadOrderDetails();
                LoadOrderItems();

                AddNewOrderbtn.Enabled = false;
                addBtn.Enabled = true;
                printOrderBtn.Enabled = true;
                cancleOrderBtn.Enabled = true;
                CustomergroupBox.Enabled = true;
                PayGroupBox.Enabled = true;
                AddItemGroupBox.Enabled = true;
            }

        }

        private void LoadOrderItems()
        {
            shoppingCart = GetAllOrderItems();
            CartdataGridView.DataSource = shoppingCart;
        }

        private List<CartItemNames> GetAllOrderItems()
        {
            List<CartItemNames> carts = new List<CartItemNames>();

            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT oi.*, p.itemName AS ItemName FROM ([OrderItems] oi INNER JOIN [DataEntered] p ON oi.ProductId = p.ID)  WHERE oi.OrderNumber=@OrderNumber", conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@OrderNumber", this.OrderNumber);

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        CartItemNames item = new CartItemNames();
                        item.ItemID = Convert.ToInt16(reader["ProductId"]);
                        item.ItemName = reader["ItemName"].ToString();
                        item.Quantity = Convert.ToInt16(reader["Quantity"]);
                        item.ItemPrice = Convert.ToDecimal(reader["ItemPrice"]);
                        item.Extra = Convert.ToInt16(reader["Extra"]);
                        item.TotalPrice = Convert.ToDecimal(reader["TotalPrice"]);

                        carts.Add(item);
                    }
                }
            }

            return carts;
        }

        private void LoadOrderDetails()
        {
            DataTable dtOrderDetails = GetOrderDetails();
            DataRow row = dtOrderDetails.Rows[0];

            txtBoxOrderId.Text = row["OrderNumber"].ToString();
            dateTimePickerCustomer.Value = Convert.ToDateTime(row["TransactionDate"]).Date;
            txtBoxCustomerName.Text = row["ClientName"].ToString();
            txtBoxMobileNo.Text = row["MobileNo"].ToString();
            txtBoxTotalAmount.Text = row["TotalAmount"].ToString();
            txtBoxUserPaid.Text = row["UserPay"].ToString();
            txtBoxRemaing.Text = row["UserRemaing"].ToString();
        }

        private DataTable GetOrderDetails()
        {
            DataTable dtOrderDetails = new DataTable();

            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM [Orders] WHERE [OrderNumber]=@OrderNumber", conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@OrderNumber", this.OrderNumber);

                    SqlDataReader reader = cmd.ExecuteReader();

                    dtOrderDetails.Load(reader);
                }
            }

            return dtOrderDetails;
        }

        private void LoadDataIntoComboBoxes()
        {
            LoadDataIntoProductsComboBox();
        }

        private void LoadDataIntoProductsComboBox()
        {
            ComboBoxItemName.SelectedValueChanged -= ComboBoxItemName_SelectedValueChanged;

            ComboBoxItemName.DataSource = GetProductsName();
            ComboBoxItemName.DisplayMember = "itemName";
            ComboBoxItemName.ValueMember = "ID";

            ComboBoxItemName.SelectedIndex = -1;

            ComboBoxItemName.SelectedValueChanged += ComboBoxItemName_SelectedValueChanged;
        }

        private DataTable GetProductsName()
        {
            DataTable dtProducts = new DataTable();

            string connString = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT  ID,itemName FROM DataEntered", conn))

                {
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    dtProducts.Load(reader);
                }
            }

            return dtProducts;
        }



        private void AddNewOrderbtn_Click(object sender, EventArgs e)
        {
            string orderNumber;
            bool isOrderNumAlreadyExist = true;

            while (isOrderNumAlreadyExist)
            {
                orderNumber = GenerateOrderNumber();

                isOrderNumAlreadyExist = CheckIfOrderNumberExists(orderNumber);

                txtBoxOrderId.Text = orderNumber;
            }
            AddNewOrderbtn.Enabled = false;
            addBtn.Enabled = true;
          
            PayGroupBox.Enabled = true;
            AddItemGroupBox.Enabled = true;
            CustomergroupBox.Enabled = true;
           
            txtBoxCustomerName.Focus();
        }

        private bool CheckIfOrderNumberExists(string orderNumber)
        {
            bool doesOrderNumberExist = false;

            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand  cmd= new SqlCommand("SELECT * FROM Orders WHERE [OrderNumber]=@OrderNumber", conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@OrderNumber", orderNumber );

                    DataTable dtAnyData = new DataTable();

                    SqlDataReader reader = cmd.ExecuteReader();

                    dtAnyData.Load(reader);

                    if (dtAnyData.Rows.Count > 0)
                    {
                        doesOrderNumberExist = true;
                    }

                }
            }

            return doesOrderNumberExist;

        }

        private string GenerateOrderNumber()
        {
            string orderNumber;

            // JI-XXXXXXXXX-XXXX
            Random rnd = new Random();
            long orderpart1 = rnd.Next(100000, 9999999);
            int orderpart2 = rnd.Next(1000, 9999);

            orderNumber = "BKS-" + orderpart1 + "-" + orderpart2;

            return orderNumber;
        }

        private void PrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Image image = Properties.Resources.logo2;
            //نام تعداد قیمت کل قیمت
            //e.Graphics.DrawImage(image, 0, 0, image.Width, image.Height);

            e.Graphics.DrawString("Date: " + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 160));
            e.Graphics.DrawString("Client Name: " + txtBoxCustomerName.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 190));
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 235));
            e.Graphics.DrawString("Item Name", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(30, 255));
            e.Graphics.DrawString("Quantity", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(380, 255));
            e.Graphics.DrawString("Price", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(500, 255));
            e.Graphics.DrawString("Extra", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(590, 255));

            e.Graphics.DrawString("Total Price", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(680, 255));
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 270));
            int y_axis_Position = 295;
            for (int i = numberOfItemsPrintedSoFar; i < shoppingCart.Count; i++)
            {
                numberOfItemsPerPage++;

                if (numberOfItemsPerPage <= 25)
                {
                    numberOfItemsPrintedSoFar++;

                    if (numberOfItemsPrintedSoFar <= shoppingCart.Count)
                    {
                        e.Graphics.DrawString(shoppingCart[i].ItemName, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(30, y_axis_Position));
                        e.Graphics.DrawString(shoppingCart[i].Quantity.ToString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(380, y_axis_Position));
                        e.Graphics.DrawString(shoppingCart[i].ItemPrice.ToString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(500, y_axis_Position));
                        e.Graphics.DrawString(shoppingCart[i].Extra.ToString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(590, y_axis_Position));

                        e.Graphics.DrawString(shoppingCart[i].TotalPrice.ToString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(680, y_axis_Position));

                        y_axis_Position += 30;
                    }
                    else
                    {
                        e.HasMorePages = false;
                    }
                }
                else
                {
                    numberOfItemsPerPage = 0;
                    e.HasMorePages = true;
                    return;
                }
            }
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, y_axis_Position));
            e.Graphics.DrawString("Total Amount:  (Rs) " + txtBoxTotalAmount.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(550, y_axis_Position + 30));
            e.Graphics.DrawString("User Pay:          (Rs) " + txtBoxUserPaid.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(550, y_axis_Position + 60));
            e.Graphics.DrawString("Remaing:          (Rs) " + txtBoxRemaing.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(550, y_axis_Position + 90));

            // reset the variables
            numberOfItemsPerPage = 0;
            numberOfItemsPrintedSoFar = 0;
        }

        private void printOrderBtn_Click(object sender, EventArgs e)
        {
            PrintDocument.Print();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            if (IsValidated())


            {
                if (Convert.ToInt16(txtBoxQuantityMinus.Text.Trim()) > Convert.ToInt16(txtBoxQuantity.Text))
                {
                    MessageBox.Show("Quantity can't be greater than current stock!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                bool hasSameProductSelectedAgain = false;

                foreach (DataGridViewRow row in CartdataGridView.Rows)
                {
                    if (Convert.ToInt16(row.Cells["ItemID"].Value) == Convert.ToInt16(ComboBoxItemName.SelectedValue))
                    {
                        row.Cells["Quantity"].Value  = Convert.ToInt16(row.Cells["Quantity"].Value) + Convert.ToInt16(txtBoxQuantityMinus.Text);
                        row.Cells["Extra"].Value = Convert.ToInt16(row.Cells["Extra"].Value) + (Convert.ToInt16(txtBoxNewExtra.Text) * Convert.ToInt16(txtBoxExtra.Text));

                        row.Cells["TotalPrice"].Value = (Convert.ToInt16(row.Cells["Quantity"].Value) * Convert.ToDecimal(row.Cells["ItemPrice"].Value) + Convert.ToInt16(row.Cells["Extra"].Value));
                        hasSameProductSelectedAgain = true;
                    }
                }
                if (hasSameProductSelectedAgain == false)
                {
                    CartItemNames itemData = new CartItemNames()
                    {

                        ItemID = Convert.ToInt16(ComboBoxItemName.SelectedValue),
                        ItemName = ComboBoxItemName.Text,

                        Quantity = Convert.ToInt16(txtBoxQuantityMinus.Text.Trim()),
                        ItemPrice = Convert.ToDecimal(txtBoxPrice.Text.Trim()),
                        Extra = Convert.ToInt16(txtBoxNewExtra.Text.Trim()) * Convert.ToInt16(txtBoxExtra.Text.Trim()),


                       
                        TotalPrice = (Convert.ToInt16(txtBoxPrice.Text.Trim()) * Convert.ToDecimal(txtBoxQuantityMinus.Text.Trim()) + Convert.ToInt16(txtBoxNewExtra.Text.Trim()) * Convert.ToDecimal(txtBoxExtra.Text.Trim()))

                    };
                    // Array, Collection, List, DataTable and DataSet



                    shoppingCart.Add(itemData);

                    CartdataGridView.DataSource = null;
                    CartdataGridView.DataSource = shoppingCart;
                }
                decimal totalAmount = shoppingCart.Sum(x => x.TotalPrice);
                txtBoxTotalAmount.Text = totalAmount.ToString();


                // Update Stock
                int productId = Convert.ToInt16(ComboBoxItemName.SelectedValue);
                int quantity = Convert.ToInt16(txtBoxQuantityMinus.Text);
                int extraQuantity= Convert.ToInt16(txtBoxNewExtra.Text);
                int totalMinus = Convert.ToInt32(txtBoxTotalMinus.Text);
                //int totalMinus = Convert.ToInt16(txtBoxTotalMinus.Text);

                UpdateStockLevel(productId, quantity);
                UpdateExtraStockLevel(productId, extraQuantity);

                UpdateTotalStockLevel(productId, totalMinus);


                ComboBoxItemName.SelectedIndex = -1;
                txtBoxPrice.Clear();
                txtBoxQuantityMinus.Clear();
                txtBoxNewExtra.Clear();
                txtBoxTotalMinus.Clear();

                cancleOrderBtn.Enabled = true;
                printOrderBtn.Enabled = true;


            }
        }

        private void UpdateExtraStockLevel(int productId, int extraQuantity)
        {
            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE DataEntered SET [KhaliBoriQuantity]=[KhaliBoriQuantity]-@MinusExtra WHERE ID=@Id", conn))

                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@MinusExtra", extraQuantity);

                    cmd.Parameters.AddWithValue("@Id", productId);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void UpdateTotalStockLevel(int productId, int totalMinus)
        {
            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE DataEntered SET [itemTotalPrice]=[itemTotalPrice]-@Minus WHERE ID=@Id", conn))

                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@Minus", totalMinus);

                    cmd.Parameters.AddWithValue("@Id", productId);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void UpdateStockLevel(int productId, int quantity)

        {
            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE DataEntered SET [itemQuentity]=[itemQuentity]-@Quantity WHERE ID=@Id", conn))

                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@Quantity", quantity);

                    cmd.Parameters.AddWithValue("@Id", productId);

                    cmd.ExecuteNonQuery();
                }
            }
        }

       

        private bool IsValidated()
        {
            if (txtBoxCustomerName.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Client Name is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBoxCustomerName.Clear();
                txtBoxCustomerName.Focus();

                return false;
            }
            if (txtBoxMobileNo.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Mobile number is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBoxMobileNo.Clear();
                txtBoxMobileNo.Focus();

                return false;
            }
            if (ComboBoxItemName.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Item here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ComboBoxItemName.Focus();
                return false;
            }

            if (txtBoxPrice.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Price is required!", "Keryana Store(Executed by Lasani Developers)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBoxPrice.Focus();
                return false;
            }
            else
            {
                decimal n;
                bool isDecimal = decimal.TryParse(txtBoxPrice.Text.Trim(), out n);

                if (!isDecimal)
                {
                    MessageBox.Show("Price should be decimal value!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtBoxPrice.Clear();
                    txtBoxPrice.Focus();
                    return false;
                }
            }
            if (txtBoxQuantityMinus.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Quantity is required!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBoxQuantityMinus.Focus();
                return false;
            }
            else
            {
                int tempQuantity;
                bool isNumeric = int.TryParse(txtBoxQuantityMinus.Text.Trim(), out tempQuantity);

                if (!isNumeric)
                {
                    MessageBox.Show("Quantity should be integer value!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtBoxQuantityMinus.Clear();
                    txtBoxQuantityMinus.Focus();
                    return false;
                }
            }
            if (txtBoxNewExtra.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Extra charges is required!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBoxNewExtra.Focus();
                return false;
            }
            else
            {
                int Extra;
                bool isNumeric = int.TryParse(txtBoxNewExtra.Text.Trim(), out Extra);

                if (!isNumeric)
                {
                    MessageBox.Show("Extra charges should be integer value!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtBoxNewExtra.Clear();
                    txtBoxNewExtra.Focus();
                    return false;
                }
            }



            return true;
        }

       

        private void cancleOrderBtn_Click(object sender, EventArgs e)
        {
           
            if (this.IsUpdate)
            {
                this.Close();

            }
            else
            {
                AddNewOrderbtn.Enabled = true;
            ComboBoxItemName.SelectedIndex = -1;
            addBtn.Enabled = false;
            CustomergroupBox.Enabled = false;
            //paidBtn.Enabled = false;
            //unPaidBtn.Enabled = false;
            cancleOrderBtn.Enabled = false;
            printOrderBtn.Enabled = false;
            PayGroupBox.Enabled = false;
            AddItemGroupBox.Enabled = false;
            txtBoxCustomerName.Clear();
            txtBoxMobileNo.Clear();

            txtBoxPrice.Clear();
            txtBoxQuantityMinus.Clear();
            txtBoxNewExtra.Clear();
            txtBoxTotalMinus.Clear();
            txtBoxOrderId.Clear();
            txtBoxTotalAmount.Clear();
            txtBoxUserPaid.Clear();
            txtBoxRemaing.Clear();

            UpdateStocks();
            CartdataGridView.DataSource = null;
            shoppingCart.Clear();
            }
        }
        private void UpdateStocks()
        {
            foreach (DataGridViewRow row in CartdataGridView.Rows)
            {
                if (this.IsUpdate)

                {
                
                }
                else { 
                int productId = Convert.ToInt16(row.Cells["ItemID"].Value);
                int quantity = Convert.ToInt16(row.Cells["Quantity"].Value) * -1;
                UpdateStockLevel(productId, quantity);

                    int extraQuantity = Convert.ToInt16(row.Cells["Extra"].Value)/ Convert.ToInt16(txtBoxExtra.Text) * -1;
                    UpdateExtraStockLevel(productId, extraQuantity);

                    int totalMinus = Convert.ToInt16(row.Cells["TotalPrice"].Value) * -1;
                    UpdateTotalStockLevel(productId, totalMinus);
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            
                int index = CartdataGridView.CurrentCell.RowIndex;

                //Update Stock Level
                int productId = Convert.ToInt16(CartdataGridView.Rows[index].Cells["ItemID"].Value);
                int quantity = Convert.ToInt16(CartdataGridView.Rows[index].Cells["Quantity"].Value) * -1;
                UpdateStockLevel(productId, quantity);
            int extraQuantity = Convert.ToInt16(CartdataGridView.Rows[index].Cells["Extra"].Value) / Convert.ToInt16(txtBoxExtra.Text) * -1;
            UpdateExtraStockLevel(productId, extraQuantity);

            int totalMinus = Convert.ToInt16(CartdataGridView.Rows[index].Cells["TotalPrice"].Value) * -1;
            UpdateTotalStockLevel(productId, totalMinus);


            shoppingCart.RemoveAt(index);
                CartdataGridView.DataSource = null;
                CartdataGridView.DataSource = shoppingCart;

                txtBoxUserPaid.Clear();

                decimal totalAmount = shoppingCart.Sum(x => x.TotalPrice);
                txtBoxTotalAmount.Text = totalAmount.ToString();
            
             if (shoppingCart.Count <= 0)
            {
                txtBoxTotalAmount.Clear();
                txtBoxUserPaid.Clear();
                txtBoxRemaing.Clear();
                paidBtn.Enabled = false;
                unPaidBtn.Enabled = false;
                cancleOrderBtn.Enabled = false;
                printOrderBtn.Enabled = false;

            }
        }

        private void ComboBoxItemName_SelectedValueChanged(object sender, EventArgs e)
        {
            if (ComboBoxItemName.SelectedValue != null) {
                int itemId = Convert.ToInt16(ComboBoxItemName.SelectedValue);
                DataTable dtItemPrice = GetItemDetails(itemId);
                DataRow row = dtItemPrice.Rows[0];

                txtBoxPrice.Text = row["itemPrice"].ToString();
                txtBoxQuantity.Text = row["itemQuentity"].ToString();
                txtBoxExtra.Text = row["khaliBoriPrice"].ToString();
                textBoxExtraQuantity.Text = row["KhaliBoriQuantity"].ToString();
                txtBoxTotal.Text = row["itemTotalPrice"].ToString();

              
            }
        }

        private DataTable GetItemDetails(int itemId)
        {
            DataTable dtItemDetails = new DataTable();
            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT itemPrice ,itemQuentity,KhaliBoriQuantity,khaliBoriPrice,itemTotalPrice FROM DataEntered WHERE ID=@Id", conn))
                {
                    conn.Open();

                    cmd.Parameters.AddWithValue("@Id", itemId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    dtItemDetails.Load(reader);

                }
            }
            return dtItemDetails;

        }

        private void txtBoxCustomerName_TextChanged(object sender, EventArgs e)
        {
            txtBoxCustomerName.CharacterCasing = CharacterCasing.Upper;
        }

        private void txtBoxUserPaid_TextChanged(object sender, EventArgs e)
        {
            decimal m,n;
             decimal.TryParse(txtBoxTotalAmount.Text.Trim(), out m);
            decimal.TryParse(txtBoxUserPaid.Text.Trim(), out n);
            //i = m - n;
            if(n >= m)
            {
                paidBtn.Enabled = true;
                unPaidBtn.Enabled = false;
            }
            else
            {
                unPaidBtn.Enabled = true;
                paidBtn.Enabled = false;
            }

           
            if (txtBoxUserPaid.Text.Trim() == string.Empty)
            {
                txtBoxUserPaid.Text = "";
                txtBoxRemaing.Text = "";
            }
            else if (txtBoxUserPaid.Text.Trim() == "0")
            {

                //txtBoxRemaing.Text = "";
                decimal remaing = Convert.ToDecimal(txtBoxTotalAmount.Text) - Convert.ToDecimal(txtBoxUserPaid.Text);
                txtBoxRemaing.Text = remaing.ToString();
                
            }
            else if (txtBoxUserPaid.Text.Length > 0)
            {
                decimal remaing = Convert.ToDecimal(txtBoxTotalAmount.Text) - Convert.ToDecimal(txtBoxUserPaid.Text);
                txtBoxRemaing.Text = remaing.ToString();
               
            }
            else
            {
                txtBoxRemaing.Text = "";

            }
          
        }

        private void CartdataGridView_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                var hti = CartdataGridView.HitTest(e.X, e.Y);
                CartdataGridView.Rows[hti.RowIndex].Selected = true;

                ContextMenuStrip.Show(CartdataGridView, e.X, e.Y);
            }
        }

      

        private void txtBoxCustomerName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetterOrDigit(e.KeyChar)) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }



  

        private void txtBoxQuantityMinus_TextChanged(object sender, EventArgs e)
        {
           
            if (txtBoxQuantityMinus.Text.Trim() == string.Empty)
            {

               
                txtBoxTotalMinus.Text = "";


            }
            else if (txtBoxNewExtra.Text.Trim() == string.Empty)
            {
                TotalMinus = (Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantityMinus.Text));
                txtBoxTotalMinus.Text = TotalMinus.ToString();
                //txtBoxTotalMinus.Text = "";

            }
            else if (txtBoxQuantityMinus.Text.Trim() == "0")
            {

                TotalMinus = (Convert.ToInt16(txtBoxNewExtra.Text) * Convert.ToInt16(txtBoxExtra.Text));
                txtBoxTotalMinus.Text = TotalMinus.ToString();

            }
            else if (txtBoxQuantityMinus.Text.Length > 0)
            {

                TotalMinus = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantityMinus.Text)) + (Convert.ToInt16(txtBoxNewExtra.Text) * Convert.ToInt16(txtBoxExtra.Text)));
                txtBoxTotalMinus.Text = TotalMinus.ToString();
            }
        


        }

        private void txtBoxNewExtra_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtBoxNewExtra.Text.Trim() == string.Empty)
                {
                    
                    txtBoxTotalMinus.Text = "";

                }
                else if (txtBoxQuantityMinus.Text.Trim() == string.Empty)
                {

                    TotalMinus = (Convert.ToInt16(txtBoxNewExtra.Text) * Convert.ToInt16(txtBoxExtra.Text));
                    txtBoxTotalMinus.Text = TotalMinus.ToString();


                }
                else if (txtBoxNewExtra.Text.Trim() == "0")
                {

                   
                    TotalMinus = Convert.ToDecimal(txtBoxQuantityMinus.Text) * Convert.ToDecimal(txtBoxPrice.Text);
                    txtBoxTotalMinus.Text = TotalMinus.ToString();
                }
                else if(txtBoxNewExtra.Text.Length > 0)
                {
                    TotalMinus = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuantityMinus.Text)) + (Convert.ToInt16(txtBoxNewExtra.Text) * Convert.ToInt16(txtBoxExtra.Text) ));
                    txtBoxTotalMinus.Text = TotalMinus.ToString();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }


        }

        private void PrintOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
            UpdateStocks();
        }

        private void MobileQuantityExtraUserPaid(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar)) && !char.IsControl(e.KeyChar) )
            {
                e.Handled = true;
            }
        }

        private void paidBtn_Click(object sender, EventArgs e)
        {
            if (txtBoxUserPaid.Text.Trim() == string.Empty)
            {
                txtBoxUserPaid.Focus();
            }
            if (this.IsUpdate)
            {
                UpdateOrder((int)PaymentGivenorNot.Paid);
            }
            else
                SaveOrder((int)PaymentGivenorNot.Paid);

        }

        private void UpdateOrder(int UpdatepaymentGivenorNot)
        {

            SqlTransaction trans = null;
            try
            {


                string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connstring))
                {
                    conn.Open();

                    trans = conn.BeginTransaction();

                    using (SqlCommand cmd = new SqlCommand("UPDATE [Orders] SET TransactionDate=@TransactionDate,ClientName=@ClientName,MobileNo=@MobileNo,TotalAmount=@TotalAmount,UserPay=@UserPay,UserRemaing=@UserRemaing,Payment=@Payment WHERE OrderNumber=@OrderNumber", conn))

                    {
                        cmd.Transaction = trans;
                        cmd.Parameters.AddWithValue("@OrderNumber", txtBoxOrderId.Text);
                        cmd.Parameters.AddWithValue("@TransactionDate", dateTimePickerCustomer.Value.Date);
                        cmd.Parameters.AddWithValue("@ClientName", txtBoxCustomerName.Text);
                        cmd.Parameters.AddWithValue("@MobileNo", txtBoxMobileNo.Text);
                        cmd.Parameters.AddWithValue("@TotalAmount", Convert.ToDecimal(txtBoxTotalAmount.Text));
                        cmd.Parameters.AddWithValue("@UserPay", Convert.ToDecimal(txtBoxUserPaid.Text));
                        cmd.Parameters.AddWithValue("@UserRemaing", Convert.ToDecimal(txtBoxRemaing.Text));
                        cmd.Parameters.AddWithValue("@Payment", UpdatepaymentGivenorNot);
                        cmd.ExecuteNonQuery();

                    }
                    //DELETE Previous orders items and insert new orders items

                                using (SqlCommand cmd = new SqlCommand("DELETE FROM [OrderItems] WHERE OrderNumber=@OrderNumber", conn))
                    {
                        cmd.Transaction = trans;

                        cmd.Parameters.AddWithValue("@OrderNumber", this.OrderNumber);

                        cmd.ExecuteNonQuery();
                    }
                    foreach (DataGridViewRow row in CartdataGridView.Rows)
                    {
                       
                        using (SqlCommand cmd = new SqlCommand("INSERT INTO [OrderItems](OrderNumber,TranscationDate,ProductId,Quantity,ItemPrice,Extra,TotalPrice) VALUES(@OrderNumber,@TranscationDate,@ProductId,@Quantity,@ItemPrice,@Extra,@TotalPrice)", conn))
                    {
                        cmd.Transaction = trans;

                        cmd.Parameters.AddWithValue("@OrderNumber", txtBoxOrderId.Text);
                            cmd.Parameters.AddWithValue("@TranscationDate", dateTimePickerCustomer.Value.Date);

                            cmd.Parameters.AddWithValue("@ProductId", Convert.ToInt16(row.Cells["ItemID"].Value));
                        cmd.Parameters.AddWithValue("@Quantity", Convert.ToInt16(row.Cells["Quantity"].Value));
                        cmd.Parameters.AddWithValue("@ItemPrice", Convert.ToDecimal(row.Cells["ItemPrice"].Value));
                        cmd.Parameters.AddWithValue("@Extra", Convert.ToDecimal(row.Cells["Extra"].Value));
                        cmd.Parameters.AddWithValue("@TotalPrice", Convert.ToDecimal(row.Cells["TotalPrice"].Value));

                        cmd.ExecuteNonQuery();
                    }
                }


                //Commit the transacation
                trans.Commit();
                    MessageBox.Show("Order is Updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Clear screen for next order
                    ClearScreenForNextOrder();
                    //this.Hide();

                }
            }

            catch (Exception ex)
            {
                trans.Rollback();
                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        
    }

        private void unPaidBtn_Click(object sender, EventArgs e)
        {
            if (txtBoxUserPaid.Text.Trim() == string.Empty)
            {
                txtBoxUserPaid.Focus();
            }
            if (this.IsUpdate)
            {
                UpdateOrder((int)PaymentGivenorNot.UnPaid);

            }
            else
                SaveOrder((int)PaymentGivenorNot.UnPaid);

        }
        private void SaveOrder(int paymentGivenorNot)
        {
            SqlTransaction trans = null;
            try
            {
                string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connstring))
                {
                    conn.Open();

                    trans = conn.BeginTransaction();

                    using (SqlCommand cmd = new SqlCommand("INSERT INTO [Orders](OrderNumber,TransactionDate,ClientName,MobileNo,TotalAmount,UserPay,UserRemaing,Payment) VALUES(@OrderNumber,@TransactionDate,@ClientName,@MobileNo,@TotalAmount,@UserPay,@UserRemaing,@Payment)", conn))
                    {
                        cmd.Transaction = trans;

                        cmd.Parameters.AddWithValue("@OrderNumber", txtBoxOrderId.Text);
                        cmd.Parameters.AddWithValue("@TransactionDate", dateTimePickerCustomer.Value.Date);
                        cmd.Parameters.AddWithValue("@ClientName", txtBoxCustomerName.Text);
                        cmd.Parameters.AddWithValue("@MobileNo", txtBoxMobileNo.Text);
                        cmd.Parameters.AddWithValue("@TotalAmount", Convert.ToDecimal(txtBoxTotalAmount.Text));
                        cmd.Parameters.AddWithValue("@UserPay", Convert.ToDecimal(txtBoxUserPaid.Text));
                        cmd.Parameters.AddWithValue("@UserRemaing", Convert.ToDecimal(txtBoxRemaing.Text));
                        cmd.Parameters.AddWithValue("@Payment", paymentGivenorNot);
                        cmd.ExecuteNonQuery();

                    }
                    foreach (DataGridViewRow row in CartdataGridView.Rows)
                    {
                        using (SqlCommand cmd = new SqlCommand("INSERT INTO [OrderItems](OrderNumber,TranscationDate,ProductId,Quantity,ItemPrice,Extra,TotalPrice) VALUES(@OrderNumber,@TranscationDate,@ProductId,@Quantity,@ItemPrice,@Extra,@TotalPrice)", conn))
                        {
                            cmd.Transaction = trans;

                            cmd.Parameters.AddWithValue("@OrderNumber", txtBoxOrderId.Text);
                            cmd.Parameters.AddWithValue("@TranscationDate", dateTimePickerCustomer.Value.Date);


                            cmd.Parameters.AddWithValue("@ProductId", Convert.ToInt16(row.Cells["ItemID"].Value));
                            cmd.Parameters.AddWithValue("@Quantity", Convert.ToInt16(row.Cells["Quantity"].Value));
                            cmd.Parameters.AddWithValue("@ItemPrice", Convert.ToDecimal(row.Cells["ItemPrice"].Value));
                            cmd.Parameters.AddWithValue("@Extra", Convert.ToDecimal(row.Cells["Extra"].Value));
                            cmd.Parameters.AddWithValue("@TotalPrice", Convert.ToDecimal(row.Cells["TotalPrice"].Value));

                            cmd.ExecuteNonQuery();
                        }
                    }

                    //Commit the transacation
                    trans.Commit();
                    MessageBox.Show("Order is processed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Clear screen for next order
                    ClearScreenForNextOrder();

                }
            }

            catch (Exception ex)
            {
                trans.Rollback();
MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ClearScreenForNextOrder()
        {
            AddNewOrderbtn.Enabled = true;
            ComboBoxItemName.SelectedIndex = -1;
            addBtn.Enabled = false;
            CustomergroupBox.Enabled = false;
            //paidBtn.Enabled = false;
            //unPaidBtn.Enabled = false;
            cancleOrderBtn.Enabled = false;
            printOrderBtn.Enabled = false;
            PayGroupBox.Enabled = false;
            AddItemGroupBox.Enabled = false;
            txtBoxCustomerName.Clear();
            txtBoxMobileNo.Clear();
            txtBoxPrice.Clear();
            txtBoxQuantityMinus.Clear();
            txtBoxNewExtra.Clear();
            txtBoxTotalMinus.Clear();
            txtBoxOrderId.Clear();
            txtBoxTotalAmount.Clear();
            txtBoxUserPaid.Clear();
            txtBoxRemaing.Clear();

            CartdataGridView.DataSource = null;
            shoppingCart.Clear();
        }

      
    }
}
