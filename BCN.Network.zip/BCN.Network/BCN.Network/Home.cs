﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class BankMain : Form
    {
        public BankMain()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox8_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBoxAdd_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.ShowDialog();
        }

        private void pictureBoxUpdate_Click(object sender, EventArgs e)
        {
            Update obj = new Update();
            obj.ShowDialog();
        }

        private void pictureBoxPrint_Click(object sender, EventArgs e)
        {
            PrintOrder obj = new PrintOrder();
            obj.ShowDialog();
        }

        private void pictureBoxBankAccount_Click(object sender, EventArgs e)
        {
            Bank_Account obj = new Bank_Account();
            obj.ShowDialog();
        }

        private void pictureBoxBankHistory_Click(object sender, EventArgs e)
        {
            ShowBankData obj = new ShowBankData();
            obj.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ManageOrders obj = new ManageOrders();
            obj.ShowDialog();
        }

        private void BankMain_FormClosed(object sender, FormClosedEventArgs e)
        {
                        Application.Exit();
            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Add_Account obj = new Add_Account();
            obj.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Mange_User_Account obj = new Mange_User_Account();
            obj.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            CrystalReportComplete obj = new CrystalReportComplete();
            obj.ShowDialog();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            ChangePassword obj = new ChangePassword();
            obj.ShowDialog();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            crystalreportForm obj = new crystalreportForm();
            obj.ShowDialog();
        }
    }
}
