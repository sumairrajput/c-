﻿namespace BCN.Network
{
    partial class PrintOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrintOrder));
            this.panel5 = new System.Windows.Forms.Panel();
            this.CustomergroupBox = new System.Windows.Forms.GroupBox();
            this.txtBoxMobileNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePickerCustomer = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBoxCustomerName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBoxOrderId = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.CartdataGridView = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.unPaidBtn = new System.Windows.Forms.Button();
            this.paidBtn = new System.Windows.Forms.Button();
            this.printOrderBtn = new System.Windows.Forms.Button();
            this.cancleOrderBtn = new System.Windows.Forms.Button();
            this.addBtn = new System.Windows.Forms.Button();
            this.AddNewOrderbtn = new System.Windows.Forms.Button();
            this.AddItemGroupBox = new System.Windows.Forms.GroupBox();
            this.ComboBoxItemName = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txtBoxTotalMinus = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtBoxNewExtra = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtBoxQuantityMinus = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtBoxPrice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.PayGroupBox = new System.Windows.Forms.GroupBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtBoxRemaing = new System.Windows.Forms.TextBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txtBoxUserPaid = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txtBoxTotalAmount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBoxExtra = new System.Windows.Forms.TextBox();
            this.txtBoxTotal = new System.Windows.Forms.TextBox();
            this.txtBoxQuantity = new System.Windows.Forms.TextBox();
            this.PrintPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.PrintDocument = new System.Drawing.Printing.PrintDocument();
            this.ContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.changeExtraChargesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeQuantityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxExtraQuantity = new System.Windows.Forms.TextBox();
            this.CustomergroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CartdataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.AddItemGroupBox.SuspendLayout();
            this.PayGroupBox.SuspendLayout();
            this.ContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.Green;
            this.panel5.Location = new System.Drawing.Point(-17, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1021, 5);
            this.panel5.TabIndex = 115;
            // 
            // CustomergroupBox
            // 
            this.CustomergroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CustomergroupBox.BackColor = System.Drawing.Color.Silver;
            this.CustomergroupBox.Controls.Add(this.txtBoxMobileNo);
            this.CustomergroupBox.Controls.Add(this.label5);
            this.CustomergroupBox.Controls.Add(this.dateTimePickerCustomer);
            this.CustomergroupBox.Controls.Add(this.label11);
            this.CustomergroupBox.Controls.Add(this.txtBoxCustomerName);
            this.CustomergroupBox.Controls.Add(this.label10);
            this.CustomergroupBox.Controls.Add(this.txtBoxOrderId);
            this.CustomergroupBox.Controls.Add(this.label9);
            this.CustomergroupBox.Enabled = false;
            this.CustomergroupBox.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomergroupBox.Location = new System.Drawing.Point(179, 14);
            this.CustomergroupBox.Name = "CustomergroupBox";
            this.CustomergroupBox.Size = new System.Drawing.Size(810, 97);
            this.CustomergroupBox.TabIndex = 152;
            this.CustomergroupBox.TabStop = false;
            this.CustomergroupBox.Text = "Customer Details";
            // 
            // txtBoxMobileNo
            // 
            this.txtBoxMobileNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxMobileNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxMobileNo.Location = new System.Drawing.Point(410, 43);
            this.txtBoxMobileNo.MaxLength = 11;
            this.txtBoxMobileNo.Name = "txtBoxMobileNo";
            this.txtBoxMobileNo.Size = new System.Drawing.Size(154, 34);
            this.txtBoxMobileNo.TabIndex = 901;
            this.txtBoxMobileNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MobileQuantityExtraUserPaid);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(406, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 24);
            this.label5.TabIndex = 902;
            this.label5.Text = "Mobile No:";
            // 
            // dateTimePickerCustomer
            // 
            this.dateTimePickerCustomer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePickerCustomer.CalendarFont = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerCustomer.CustomFormat = "dd/MM/yyyy";
            this.dateTimePickerCustomer.Font = new System.Drawing.Font("Georgia", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerCustomer.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerCustomer.Location = new System.Drawing.Point(570, 43);
            this.dateTimePickerCustomer.Name = "dateTimePickerCustomer";
            this.dateTimePickerCustomer.Size = new System.Drawing.Size(196, 34);
            this.dateTimePickerCustomer.TabIndex = 900;
            this.dateTimePickerCustomer.TabStop = false;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(566, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(183, 24);
            this.label11.TabIndex = 106;
            this.label11.Text = "Transction Date:";
            // 
            // txtBoxCustomerName
            // 
            this.txtBoxCustomerName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxCustomerName.Location = new System.Drawing.Point(250, 43);
            this.txtBoxCustomerName.Name = "txtBoxCustomerName";
            this.txtBoxCustomerName.Size = new System.Drawing.Size(154, 34);
            this.txtBoxCustomerName.TabIndex = 0;
            this.txtBoxCustomerName.TextChanged += new System.EventHandler(this.txtBoxCustomerName_TextChanged);
            this.txtBoxCustomerName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxCustomerName_KeyPress);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(246, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(143, 24);
            this.label10.TabIndex = 105;
            this.label10.Text = "Client Name:";
            // 
            // txtBoxOrderId
            // 
            this.txtBoxOrderId.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxOrderId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxOrderId.Enabled = false;
            this.txtBoxOrderId.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxOrderId.Location = new System.Drawing.Point(75, 43);
            this.txtBoxOrderId.Name = "txtBoxOrderId";
            this.txtBoxOrderId.Size = new System.Drawing.Size(169, 34);
            this.txtBoxOrderId.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(71, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 24);
            this.label9.TabIndex = 105;
            this.label9.Text = "Order Id:";
            // 
            // CartdataGridView
            // 
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CartdataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.CartdataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CartdataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CartdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CartdataGridView.Location = new System.Drawing.Point(179, 217);
            this.CartdataGridView.MultiSelect = false;
            this.CartdataGridView.Name = "CartdataGridView";
            this.CartdataGridView.RowTemplate.Height = 24;
            this.CartdataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CartdataGridView.Size = new System.Drawing.Size(809, 308);
            this.CartdataGridView.TabIndex = 153;
            this.CartdataGridView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CartdataGridView_MouseDown);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.unPaidBtn);
            this.panel1.Controls.Add(this.paidBtn);
            this.panel1.Controls.Add(this.printOrderBtn);
            this.panel1.Controls.Add(this.cancleOrderBtn);
            this.panel1.Controls.Add(this.addBtn);
            this.panel1.Controls.Add(this.AddNewOrderbtn);
            this.panel1.Location = new System.Drawing.Point(-1, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(165, 632);
            this.panel1.TabIndex = 154;
            // 
            // unPaidBtn
            // 
            this.unPaidBtn.BackColor = System.Drawing.Color.DimGray;
            this.unPaidBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.unPaidBtn.Enabled = false;
            this.unPaidBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.unPaidBtn.FlatAppearance.BorderSize = 0;
            this.unPaidBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.unPaidBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.unPaidBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unPaidBtn.ForeColor = System.Drawing.Color.White;
            this.unPaidBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.unPaidBtn.Location = new System.Drawing.Point(-6, 421);
            this.unPaidBtn.Name = "unPaidBtn";
            this.unPaidBtn.Size = new System.Drawing.Size(179, 66);
            this.unPaidBtn.TabIndex = 7;
            this.unPaidBtn.Text = "&Not Pay";
            this.unPaidBtn.UseVisualStyleBackColor = false;
            this.unPaidBtn.Click += new System.EventHandler(this.unPaidBtn_Click);
            // 
            // paidBtn
            // 
            this.paidBtn.BackColor = System.Drawing.Color.DimGray;
            this.paidBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.paidBtn.Enabled = false;
            this.paidBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.paidBtn.FlatAppearance.BorderSize = 0;
            this.paidBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.paidBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.paidBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paidBtn.ForeColor = System.Drawing.Color.White;
            this.paidBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.paidBtn.Location = new System.Drawing.Point(-6, 355);
            this.paidBtn.Name = "paidBtn";
            this.paidBtn.Size = new System.Drawing.Size(179, 66);
            this.paidBtn.TabIndex = 6;
            this.paidBtn.Text = "&Pay Bill";
            this.paidBtn.UseVisualStyleBackColor = false;
            this.paidBtn.Click += new System.EventHandler(this.paidBtn_Click);
            // 
            // printOrderBtn
            // 
            this.printOrderBtn.BackColor = System.Drawing.Color.DimGray;
            this.printOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printOrderBtn.Enabled = false;
            this.printOrderBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.printOrderBtn.FlatAppearance.BorderSize = 0;
            this.printOrderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.printOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.printOrderBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printOrderBtn.ForeColor = System.Drawing.Color.White;
            this.printOrderBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printOrderBtn.Location = new System.Drawing.Point(-6, 289);
            this.printOrderBtn.Name = "printOrderBtn";
            this.printOrderBtn.Size = new System.Drawing.Size(179, 66);
            this.printOrderBtn.TabIndex = 5;
            this.printOrderBtn.Text = "Print Order";
            this.printOrderBtn.UseVisualStyleBackColor = false;
            this.printOrderBtn.Click += new System.EventHandler(this.printOrderBtn_Click);
            // 
            // cancleOrderBtn
            // 
            this.cancleOrderBtn.BackColor = System.Drawing.Color.DimGray;
            this.cancleOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancleOrderBtn.Enabled = false;
            this.cancleOrderBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.cancleOrderBtn.FlatAppearance.BorderSize = 0;
            this.cancleOrderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.cancleOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancleOrderBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancleOrderBtn.ForeColor = System.Drawing.Color.White;
            this.cancleOrderBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancleOrderBtn.Location = new System.Drawing.Point(-6, 223);
            this.cancleOrderBtn.Name = "cancleOrderBtn";
            this.cancleOrderBtn.Size = new System.Drawing.Size(179, 66);
            this.cancleOrderBtn.TabIndex = 4;
            this.cancleOrderBtn.Text = "Cancle Order";
            this.cancleOrderBtn.UseVisualStyleBackColor = false;
            this.cancleOrderBtn.Click += new System.EventHandler(this.cancleOrderBtn_Click);
            // 
            // addBtn
            // 
            this.addBtn.BackColor = System.Drawing.Color.DimGray;
            this.addBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addBtn.Enabled = false;
            this.addBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.addBtn.FlatAppearance.BorderSize = 0;
            this.addBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.ForeColor = System.Drawing.Color.White;
            this.addBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addBtn.Location = new System.Drawing.Point(-6, 157);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(179, 66);
            this.addBtn.TabIndex = 3;
            this.addBtn.Text = "Add To Cart";
            this.addBtn.UseVisualStyleBackColor = false;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // AddNewOrderbtn
            // 
            this.AddNewOrderbtn.BackColor = System.Drawing.Color.DimGray;
            this.AddNewOrderbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddNewOrderbtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.AddNewOrderbtn.FlatAppearance.BorderSize = 0;
            this.AddNewOrderbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray;
            this.AddNewOrderbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.AddNewOrderbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddNewOrderbtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewOrderbtn.ForeColor = System.Drawing.Color.White;
            this.AddNewOrderbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddNewOrderbtn.Location = new System.Drawing.Point(-6, 91);
            this.AddNewOrderbtn.Name = "AddNewOrderbtn";
            this.AddNewOrderbtn.Size = new System.Drawing.Size(179, 66);
            this.AddNewOrderbtn.TabIndex = 111;
            this.AddNewOrderbtn.Text = "New Order";
            this.AddNewOrderbtn.UseVisualStyleBackColor = false;
            this.AddNewOrderbtn.Click += new System.EventHandler(this.AddNewOrderbtn_Click);
            // 
            // AddItemGroupBox
            // 
            this.AddItemGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddItemGroupBox.BackColor = System.Drawing.Color.Silver;
            this.AddItemGroupBox.Controls.Add(this.ComboBoxItemName);
            this.AddItemGroupBox.Controls.Add(this.panel9);
            this.AddItemGroupBox.Controls.Add(this.panel10);
            this.AddItemGroupBox.Controls.Add(this.txtBoxTotalMinus);
            this.AddItemGroupBox.Controls.Add(this.panel6);
            this.AddItemGroupBox.Controls.Add(this.panel14);
            this.AddItemGroupBox.Controls.Add(this.panel8);
            this.AddItemGroupBox.Controls.Add(this.txtBoxNewExtra);
            this.AddItemGroupBox.Controls.Add(this.panel2);
            this.AddItemGroupBox.Controls.Add(this.panel3);
            this.AddItemGroupBox.Controls.Add(this.txtBoxQuantityMinus);
            this.AddItemGroupBox.Controls.Add(this.panel4);
            this.AddItemGroupBox.Controls.Add(this.panel7);
            this.AddItemGroupBox.Controls.Add(this.txtBoxPrice);
            this.AddItemGroupBox.Controls.Add(this.label4);
            this.AddItemGroupBox.Controls.Add(this.label7);
            this.AddItemGroupBox.Controls.Add(this.label3);
            this.AddItemGroupBox.Controls.Add(this.label2);
            this.AddItemGroupBox.Controls.Add(this.label1);
            this.AddItemGroupBox.Enabled = false;
            this.AddItemGroupBox.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItemGroupBox.Location = new System.Drawing.Point(179, 115);
            this.AddItemGroupBox.Name = "AddItemGroupBox";
            this.AddItemGroupBox.Size = new System.Drawing.Size(810, 97);
            this.AddItemGroupBox.TabIndex = 1;
            this.AddItemGroupBox.TabStop = false;
            // 
            // ComboBoxItemName
            // 
            this.ComboBoxItemName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ComboBoxItemName.AutoCompleteCustomSource.AddRange(new string[] {
            "Amli",
            "Zeera"});
            this.ComboBoxItemName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ComboBoxItemName.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxItemName.FormattingEnabled = true;
            this.ComboBoxItemName.Location = new System.Drawing.Point(31, 37);
            this.ComboBoxItemName.Name = "ComboBoxItemName";
            this.ComboBoxItemName.Size = new System.Drawing.Size(210, 49);
            this.ComboBoxItemName.TabIndex = 1;
            this.ComboBoxItemName.SelectedValueChanged += new System.EventHandler(this.ComboBoxItemName_SelectedValueChanged);
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(652, 72);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(129, 5);
            this.panel9.TabIndex = 95;
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(652, 37);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(129, 5);
            this.panel10.TabIndex = 94;
            // 
            // txtBoxTotalMinus
            // 
            this.txtBoxTotalMinus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxTotalMinus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxTotalMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTotalMinus.Location = new System.Drawing.Point(652, 37);
            this.txtBoxTotalMinus.Name = "txtBoxTotalMinus";
            this.txtBoxTotalMinus.Size = new System.Drawing.Size(129, 41);
            this.txtBoxTotalMinus.TabIndex = 93;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(517, 72);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(129, 5);
            this.panel6.TabIndex = 92;
            // 
            // panel14
            // 
            this.panel14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel14.BackColor = System.Drawing.Color.Black;
            this.panel14.Location = new System.Drawing.Point(31, 38);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(210, 5);
            this.panel14.TabIndex = 902;
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(517, 37);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(129, 5);
            this.panel8.TabIndex = 91;
            // 
            // txtBoxNewExtra
            // 
            this.txtBoxNewExtra.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxNewExtra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxNewExtra.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxNewExtra.Location = new System.Drawing.Point(517, 37);
            this.txtBoxNewExtra.Name = "txtBoxNewExtra";
            this.txtBoxNewExtra.Size = new System.Drawing.Size(129, 41);
            this.txtBoxNewExtra.TabIndex = 90;
            this.txtBoxNewExtra.TextChanged += new System.EventHandler(this.txtBoxNewExtra_TextChanged);
            this.txtBoxNewExtra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MobileQuantityExtraUserPaid);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(382, 72);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(129, 5);
            this.panel2.TabIndex = 89;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(382, 37);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(129, 5);
            this.panel3.TabIndex = 88;
            // 
            // txtBoxQuantityMinus
            // 
            this.txtBoxQuantityMinus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxQuantityMinus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxQuantityMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxQuantityMinus.Location = new System.Drawing.Point(382, 37);
            this.txtBoxQuantityMinus.Name = "txtBoxQuantityMinus";
            this.txtBoxQuantityMinus.Size = new System.Drawing.Size(129, 41);
            this.txtBoxQuantityMinus.TabIndex = 87;
            this.txtBoxQuantityMinus.TextChanged += new System.EventHandler(this.txtBoxQuantityMinus_TextChanged);
            this.txtBoxQuantityMinus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MobileQuantityExtraUserPaid);
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(246, 72);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(129, 5);
            this.panel4.TabIndex = 86;
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(246, 37);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(129, 5);
            this.panel7.TabIndex = 85;
            // 
            // txtBoxPrice
            // 
            this.txtBoxPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxPrice.Enabled = false;
            this.txtBoxPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxPrice.Location = new System.Drawing.Point(246, 37);
            this.txtBoxPrice.Name = "txtBoxPrice";
            this.txtBoxPrice.Size = new System.Drawing.Size(129, 41);
            this.txtBoxPrice.TabIndex = 84;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(648, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 24);
            this.label4.TabIndex = 83;
            this.label4.Text = "Total Price:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(512, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 24);
            this.label7.TabIndex = 82;
            this.label7.Text = "Khali Bori:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(378, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 24);
            this.label3.TabIndex = 81;
            this.label3.Text = "Quantity:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(244, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 24);
            this.label2.TabIndex = 80;
            this.label2.Text = "Item Price:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 24);
            this.label1.TabIndex = 79;
            this.label1.Text = "Item Name:";
            // 
            // panel11
            // 
            this.panel11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(210, 153);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(210, 5);
            this.panel11.TabIndex = 902;
            // 
            // PayGroupBox
            // 
            this.PayGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PayGroupBox.BackColor = System.Drawing.Color.Silver;
            this.PayGroupBox.Controls.Add(this.panel12);
            this.PayGroupBox.Controls.Add(this.panel13);
            this.PayGroupBox.Controls.Add(this.txtBoxRemaing);
            this.PayGroupBox.Controls.Add(this.panel16);
            this.PayGroupBox.Controls.Add(this.panel17);
            this.PayGroupBox.Controls.Add(this.txtBoxUserPaid);
            this.PayGroupBox.Controls.Add(this.panel18);
            this.PayGroupBox.Controls.Add(this.panel19);
            this.PayGroupBox.Controls.Add(this.txtBoxTotalAmount);
            this.PayGroupBox.Controls.Add(this.label6);
            this.PayGroupBox.Controls.Add(this.label8);
            this.PayGroupBox.Controls.Add(this.label13);
            this.PayGroupBox.Enabled = false;
            this.PayGroupBox.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PayGroupBox.Location = new System.Drawing.Point(179, 534);
            this.PayGroupBox.Name = "PayGroupBox";
            this.PayGroupBox.Size = new System.Drawing.Size(810, 88);
            this.PayGroupBox.TabIndex = 902;
            this.PayGroupBox.TabStop = false;
            this.PayGroupBox.Text = "Payment Details";
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(498, 71);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(172, 5);
            this.panel12.TabIndex = 101;
            // 
            // panel13
            // 
            this.panel13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel13.BackColor = System.Drawing.Color.Black;
            this.panel13.Location = new System.Drawing.Point(498, 36);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(172, 5);
            this.panel13.TabIndex = 100;
            // 
            // txtBoxRemaing
            // 
            this.txtBoxRemaing.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxRemaing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxRemaing.Enabled = false;
            this.txtBoxRemaing.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxRemaing.Location = new System.Drawing.Point(498, 36);
            this.txtBoxRemaing.Name = "txtBoxRemaing";
            this.txtBoxRemaing.ReadOnly = true;
            this.txtBoxRemaing.Size = new System.Drawing.Size(171, 41);
            this.txtBoxRemaing.TabIndex = 99;
            this.txtBoxRemaing.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel16
            // 
            this.panel16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Location = new System.Drawing.Point(321, 71);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(172, 5);
            this.panel16.TabIndex = 98;
            // 
            // panel17
            // 
            this.panel17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Location = new System.Drawing.Point(321, 36);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(172, 5);
            this.panel17.TabIndex = 97;
            // 
            // txtBoxUserPaid
            // 
            this.txtBoxUserPaid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxUserPaid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxUserPaid.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxUserPaid.Location = new System.Drawing.Point(321, 36);
            this.txtBoxUserPaid.Name = "txtBoxUserPaid";
            this.txtBoxUserPaid.Size = new System.Drawing.Size(171, 41);
            this.txtBoxUserPaid.TabIndex = 96;
            this.txtBoxUserPaid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxUserPaid.TextChanged += new System.EventHandler(this.txtBoxUserPaid_TextChanged);
            this.txtBoxUserPaid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MobileQuantityExtraUserPaid);
            // 
            // panel18
            // 
            this.panel18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel18.BackColor = System.Drawing.Color.Black;
            this.panel18.Location = new System.Drawing.Point(141, 71);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(172, 5);
            this.panel18.TabIndex = 86;
            // 
            // panel19
            // 
            this.panel19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel19.BackColor = System.Drawing.Color.Black;
            this.panel19.Location = new System.Drawing.Point(141, 36);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(172, 5);
            this.panel19.TabIndex = 85;
            // 
            // txtBoxTotalAmount
            // 
            this.txtBoxTotalAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxTotalAmount.Enabled = false;
            this.txtBoxTotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTotalAmount.Location = new System.Drawing.Point(141, 36);
            this.txtBoxTotalAmount.Name = "txtBoxTotalAmount";
            this.txtBoxTotalAmount.ReadOnly = true;
            this.txtBoxTotalAmount.Size = new System.Drawing.Size(171, 41);
            this.txtBoxTotalAmount.TabIndex = 84;
            this.txtBoxTotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(494, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 24);
            this.label6.TabIndex = 82;
            this.label6.Text = "Remaing:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(316, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 24);
            this.label8.TabIndex = 81;
            this.label8.Text = "Pay:";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(139, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(160, 24);
            this.label13.TabIndex = 79;
            this.label13.Text = "Total Amount:";
            // 
            // txtBoxExtra
            // 
            this.txtBoxExtra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxExtra.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxExtra.Location = new System.Drawing.Point(498, 469);
            this.txtBoxExtra.Name = "txtBoxExtra";
            this.txtBoxExtra.Size = new System.Drawing.Size(93, 41);
            this.txtBoxExtra.TabIndex = 905;
            this.txtBoxExtra.TabStop = false;
            // 
            // txtBoxTotal
            // 
            this.txtBoxTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTotal.Location = new System.Drawing.Point(696, 469);
            this.txtBoxTotal.Name = "txtBoxTotal";
            this.txtBoxTotal.Size = new System.Drawing.Size(93, 41);
            this.txtBoxTotal.TabIndex = 904;
            this.txtBoxTotal.TabStop = false;
            // 
            // txtBoxQuantity
            // 
            this.txtBoxQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxQuantity.Location = new System.Drawing.Point(400, 469);
            this.txtBoxQuantity.Name = "txtBoxQuantity";
            this.txtBoxQuantity.Size = new System.Drawing.Size(93, 41);
            this.txtBoxQuantity.TabIndex = 903;
            this.txtBoxQuantity.TabStop = false;
            // 
            // PrintPreviewDialog
            // 
            this.PrintPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.PrintPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.PrintPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.PrintPreviewDialog.Enabled = true;
            this.PrintPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("PrintPreviewDialog.Icon")));
            this.PrintPreviewDialog.Name = "PrintPreviewDialog";
            this.PrintPreviewDialog.Visible = false;
            // 
            // PrintDocument
            // 
            this.PrintDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDocument_PrintPage);
            // 
            // ContextMenuStrip
            // 
            this.ContextMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeExtraChargesToolStripMenuItem,
            this.changeQuantityToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.ContextMenuStrip.Name = "ContextMenuStrip";
            this.ContextMenuStrip.Size = new System.Drawing.Size(223, 76);
            // 
            // changeExtraChargesToolStripMenuItem
            // 
            this.changeExtraChargesToolStripMenuItem.Name = "changeExtraChargesToolStripMenuItem";
            this.changeExtraChargesToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.changeExtraChargesToolStripMenuItem.Text = "&Change Extra Charges";
            this.changeExtraChargesToolStripMenuItem.Visible = false;
            // 
            // changeQuantityToolStripMenuItem
            // 
            this.changeQuantityToolStripMenuItem.Name = "changeQuantityToolStripMenuItem";
            this.changeQuantityToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.changeQuantityToolStripMenuItem.Text = "&Change Quantity";
            this.changeQuantityToolStripMenuItem.Visible = false;
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.deleteToolStripMenuItem.Text = "&Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // textBoxExtraQuantity
            // 
            this.textBoxExtraQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxExtraQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxExtraQuantity.Location = new System.Drawing.Point(597, 469);
            this.textBoxExtraQuantity.Name = "textBoxExtraQuantity";
            this.textBoxExtraQuantity.Size = new System.Drawing.Size(93, 41);
            this.textBoxExtraQuantity.TabIndex = 906;
            this.textBoxExtraQuantity.TabStop = false;
            // 
            // PrintOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1004, 634);
            this.Controls.Add(this.textBoxExtraQuantity);
            this.Controls.Add(this.txtBoxExtra);
            this.Controls.Add(this.txtBoxTotal);
            this.Controls.Add(this.txtBoxQuantity);
            this.Controls.Add(this.PayGroupBox);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.AddItemGroupBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CartdataGridView);
            this.Controls.Add(this.CustomergroupBox);
            this.Controls.Add(this.panel5);
            this.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "PrintOrder";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PrintOrder";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PrintOrder_FormClosing);
            this.Load += new System.EventHandler(this.PrintOrder_Load);
            this.CustomergroupBox.ResumeLayout(false);
            this.CustomergroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CartdataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.AddItemGroupBox.ResumeLayout(false);
            this.AddItemGroupBox.PerformLayout();
            this.PayGroupBox.ResumeLayout(false);
            this.PayGroupBox.PerformLayout();
            this.ContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox CustomergroupBox;
        private System.Windows.Forms.DateTimePicker dateTimePickerCustomer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBoxCustomerName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtBoxOrderId;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView CartdataGridView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button printOrderBtn;
        private System.Windows.Forms.Button cancleOrderBtn;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button AddNewOrderbtn;
        private System.Windows.Forms.GroupBox AddItemGroupBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txtBoxTotalMinus;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtBoxNewExtra;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtBoxQuantityMinus;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtBoxPrice;
        private System.Windows.Forms.ComboBox ComboBoxItemName;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button unPaidBtn;
        private System.Windows.Forms.Button paidBtn;
        private System.Windows.Forms.GroupBox PayGroupBox;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txtBoxTotalAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtBoxRemaing;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txtBoxUserPaid;
        private System.Windows.Forms.TextBox txtBoxExtra;
        private System.Windows.Forms.TextBox txtBoxTotal;
        private System.Windows.Forms.TextBox txtBoxQuantity;
        private System.Windows.Forms.PrintPreviewDialog PrintPreviewDialog;
        private System.Drawing.Printing.PrintDocument PrintDocument;
        private System.Windows.Forms.ContextMenuStrip ContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeQuantityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeExtraChargesToolStripMenuItem;
        private System.Windows.Forms.TextBox txtBoxMobileNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox textBoxExtraQuantity;
    }
}