﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace BCN.Network
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        decimal TotalCalc;
        void reset()
        {
            dateTimePicker.Text = "";
            txtBoxName.Text = "";
            txtBoxPrice.Text = "";
          comboBoxUnit.Text = "Select Unit";
            txtBoxQuentity.Text = "";
            textBoxExtraQuantity.Text = "";
            txtBoxExtra.Text = "";
            txtBoxTotalPrice.Text = "";


        }

      

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void addBtn_Click(object sender, EventArgs e)

        {

            try
            {
               
                 if ( txtBoxName.Text == "" )
                {
                    MessageBox.Show("Please enter Name here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtBoxName.Focus();
                }
                else if (txtBoxPrice.Text == "")
                {
                    MessageBox.Show("Please enter Price here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtBoxPrice.Focus();
                }
                else if (comboBoxUnit.Text == "Select Unit")
                {
                    MessageBox.Show("Please select Unit here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    comboBoxUnit.Focus();
                }
                else if (txtBoxQuentity.Text == "")
                {
                    MessageBox.Show("Please enter Quantity here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtBoxQuentity.Focus();
                }
                else if (textBoxExtraQuantity.Text == "")
                {
                    MessageBox.Show("Please enter Bori Quantity here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBoxExtraQuantity.Focus();
                }
                
                else if (txtBoxExtra.Text == "")
                {
                    MessageBox.Show("Please enter Bori Price here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtBoxExtra.Focus();
                }
                else { 
            string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(st))
            {
                SqlCommand cmm = new SqlCommand("insert into DataEntered  values ('" + dateTimePicker.Text + "','" + txtBoxName.Text + "','" + txtBoxPrice.Text + "','" + comboBoxUnit.Text + "','" + txtBoxQuentity.Text + "','" + textBoxExtraQuantity.Text + "','" + txtBoxExtra.Text + "','" + txtBoxTotalPrice.Text + "')", cnn);

                cnn.Open();


                cmm.ExecuteNonQuery();
                        MessageBox.Show("Value is Inserted...Successful!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        cnn.Close();
                reset();
                        txtBoxName.Focus();
                    }
                }

        }

            catch (ApplicationException ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store" ,MessageBoxButtons.OK, MessageBoxIcon.Error);
              

            }
}

        private void resetBtn_Click(object sender, EventArgs e)
        {
            reset();
            txtBoxName.Select();
        }

        private void txtBoxQuentity_TextChanged(object sender, EventArgs e)
        {
            

            AllCalc();
        }




        private void txtBoxTotalPrice_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtBoxPrice_TextChanged_1(object sender, EventArgs e)
        {
          

            AllCalc();
        }

        private void txtBoxExtra_TextChanged(object sender, EventArgs e)
        {
                      AllCalc();
        }

       

        private void txtBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetterOrDigit(e.KeyChar)) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }

        }



      

        private void txtBoxPrice_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void AllCalc()
        {
            try
            {
                if (txtBoxPrice.Text.Trim() == string.Empty)
                {

                    txtBoxTotalPrice.Text = "";

                }
                else if (txtBoxQuentity.Text.Trim() == string.Empty)
                {

                 
                    txtBoxTotalPrice.Text = "";



                }
                else if (textBoxExtraQuantity.Text.Trim() == string.Empty)
                {
                    txtBoxTotalPrice.Text = "";

                }
                else if (txtBoxExtra.Text.Trim() == string.Empty)
                {
                    txtBoxTotalPrice.Text = "";

                }
                else if (txtBoxPrice.Text.Trim() == "0")
                {


                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }

                else if (txtBoxQuentity.Text.Trim() == "0")
                {

                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();

                }
                else if (textBoxExtraQuantity.Text.Trim() == "0")
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();


                }
                else if (txtBoxExtra.Text.Trim() == "0")
                {


                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (txtBoxPrice.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (txtBoxQuentity.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (textBoxExtraQuantity.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
                else if (txtBoxExtra.Text.Length > 0)
                {
                    TotalCalc = ((Convert.ToDecimal(txtBoxPrice.Text) * Convert.ToDecimal(txtBoxQuentity.Text)) + (Convert.ToDecimal(textBoxExtraQuantity.Text) * Convert.ToDecimal(txtBoxExtra.Text)));
                    txtBoxTotalPrice.Text = TotalCalc.ToString();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }



        }

        private void textBoxExtraQuantity_TextChanged(object sender, EventArgs e)
        {
            AllCalc();
              
            }
       
    }
}
