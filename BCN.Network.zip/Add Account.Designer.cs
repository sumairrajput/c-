﻿namespace BCN.Network
{
    partial class Add_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Account));
            this.AddItemGroupBox = new System.Windows.Forms.GroupBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtBoxSearch = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtBoxAccountid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Updatebtn = new System.Windows.Forms.Button();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.AddNewAccountbtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtBoxUpdateTotalamount = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtBoxUpdateAccountname = new System.Windows.Forms.TextBox();
            this.dateTimePickerUpdateCreatedate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtBoxTotalamount = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txtBoxAccountname = new System.Windows.Forms.TextBox();
            this.dateTimePickerCreatedate = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AddItemGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddItemGroupBox
            // 
            this.AddItemGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddItemGroupBox.BackColor = System.Drawing.Color.Silver;
            this.AddItemGroupBox.Controls.Add(this.panel8);
            this.AddItemGroupBox.Controls.Add(this.label8);
            this.AddItemGroupBox.Controls.Add(this.panel11);
            this.AddItemGroupBox.Controls.Add(this.txtBoxSearch);
            this.AddItemGroupBox.Controls.Add(this.panel7);
            this.AddItemGroupBox.Controls.Add(this.txtBoxAccountid);
            this.AddItemGroupBox.Controls.Add(this.label4);
            this.AddItemGroupBox.Controls.Add(this.Updatebtn);
            this.AddItemGroupBox.Controls.Add(this.Deletebtn);
            this.AddItemGroupBox.Controls.Add(this.AddNewAccountbtn);
            this.AddItemGroupBox.Controls.Add(this.panel1);
            this.AddItemGroupBox.Controls.Add(this.panel2);
            this.AddItemGroupBox.Controls.Add(this.txtBoxUpdateTotalamount);
            this.AddItemGroupBox.Controls.Add(this.panel3);
            this.AddItemGroupBox.Controls.Add(this.txtBoxUpdateAccountname);
            this.AddItemGroupBox.Controls.Add(this.dateTimePickerUpdateCreatedate);
            this.AddItemGroupBox.Controls.Add(this.label1);
            this.AddItemGroupBox.Controls.Add(this.label2);
            this.AddItemGroupBox.Controls.Add(this.label3);
            this.AddItemGroupBox.Controls.Add(this.panel20);
            this.AddItemGroupBox.Controls.Add(this.panel21);
            this.AddItemGroupBox.Controls.Add(this.label7);
            this.AddItemGroupBox.Controls.Add(this.panel15);
            this.AddItemGroupBox.Controls.Add(this.panel12);
            this.AddItemGroupBox.Controls.Add(this.panel6);
            this.AddItemGroupBox.Controls.Add(this.panel9);
            this.AddItemGroupBox.Controls.Add(this.label6);
            this.AddItemGroupBox.Controls.Add(this.panel4);
            this.AddItemGroupBox.Controls.Add(this.panel17);
            this.AddItemGroupBox.Controls.Add(this.panel16);
            this.AddItemGroupBox.Controls.Add(this.txtBoxTotalamount);
            this.AddItemGroupBox.Controls.Add(this.panel10);
            this.AddItemGroupBox.Controls.Add(this.txtBoxAccountname);
            this.AddItemGroupBox.Controls.Add(this.dateTimePickerCreatedate);
            this.AddItemGroupBox.Controls.Add(this.label11);
            this.AddItemGroupBox.Controls.Add(this.label5);
            this.AddItemGroupBox.Controls.Add(this.label9);
            this.AddItemGroupBox.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItemGroupBox.Location = new System.Drawing.Point(4, 12);
            this.AddItemGroupBox.Name = "AddItemGroupBox";
            this.AddItemGroupBox.Size = new System.Drawing.Size(997, 611);
            this.AddItemGroupBox.TabIndex = 907;
            this.AddItemGroupBox.TabStop = false;
            this.AddItemGroupBox.Text = resources.GetString("AddItemGroupBox.Text");
            this.AddItemGroupBox.Enter += new System.EventHandler(this.AddItemGroupBox_Enter);
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(407, 100);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(276, 5);
            this.panel8.TabIndex = 1089;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(313, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 24);
            this.label8.TabIndex = 1090;
            this.label8.Text = "Search:";
            // 
            // panel11
            // 
            this.panel11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(407, 65);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(276, 5);
            this.panel11.TabIndex = 1088;
            // 
            // txtBoxSearch
            // 
            this.txtBoxSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxSearch.Location = new System.Drawing.Point(407, 65);
            this.txtBoxSearch.Name = "txtBoxSearch";
            this.txtBoxSearch.Size = new System.Drawing.Size(276, 41);
            this.txtBoxSearch.TabIndex = 1;
            this.txtBoxSearch.TextChanged += new System.EventHandler(this.txtBoxSearch_TextChanged);
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(498, 194);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(286, 5);
            this.panel7.TabIndex = 1086;
            // 
            // txtBoxAccountid
            // 
            this.txtBoxAccountid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxAccountid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAccountid.Enabled = false;
            this.txtBoxAccountid.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxAccountid.Location = new System.Drawing.Point(498, 194);
            this.txtBoxAccountid.Name = "txtBoxAccountid";
            this.txtBoxAccountid.Size = new System.Drawing.Size(286, 41);
            this.txtBoxAccountid.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(494, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 24);
            this.label4.TabIndex = 1084;
            this.label4.Text = "Account id:";
            // 
            // Updatebtn
            // 
            this.Updatebtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Updatebtn.BackColor = System.Drawing.Color.DimGray;
            this.Updatebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Updatebtn.Enabled = false;
            this.Updatebtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.Updatebtn.FlatAppearance.BorderSize = 0;
            this.Updatebtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray;
            this.Updatebtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.Updatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Updatebtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebtn.ForeColor = System.Drawing.Color.White;
            this.Updatebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Updatebtn.Location = new System.Drawing.Point(842, 239);
            this.Updatebtn.Name = "Updatebtn";
            this.Updatebtn.Size = new System.Drawing.Size(124, 49);
            this.Updatebtn.TabIndex = 1083;
            this.Updatebtn.Text = "Update";
            this.Updatebtn.UseVisualStyleBackColor = false;
            // 
            // Deletebtn
            // 
            this.Deletebtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Deletebtn.BackColor = System.Drawing.Color.DimGray;
            this.Deletebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Deletebtn.Enabled = false;
            this.Deletebtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.Deletebtn.FlatAppearance.BorderSize = 0;
            this.Deletebtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray;
            this.Deletebtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.Deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletebtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebtn.ForeColor = System.Drawing.Color.White;
            this.Deletebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Deletebtn.Location = new System.Drawing.Point(842, 323);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(124, 49);
            this.Deletebtn.TabIndex = 1082;
            this.Deletebtn.Text = "Delete";
            this.Deletebtn.UseVisualStyleBackColor = false;
            // 
            // AddNewAccountbtn
            // 
            this.AddNewAccountbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddNewAccountbtn.BackColor = System.Drawing.Color.DimGray;
            this.AddNewAccountbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddNewAccountbtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.AddNewAccountbtn.FlatAppearance.BorderSize = 0;
            this.AddNewAccountbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray;
            this.AddNewAccountbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.AddNewAccountbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddNewAccountbtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewAccountbtn.ForeColor = System.Drawing.Color.White;
            this.AddNewAccountbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddNewAccountbtn.Location = new System.Drawing.Point(130, 441);
            this.AddNewAccountbtn.Name = "AddNewAccountbtn";
            this.AddNewAccountbtn.Size = new System.Drawing.Size(286, 41);
            this.AddNewAccountbtn.TabIndex = 1081;
            this.AddNewAccountbtn.Text = "Add";
            this.AddNewAccountbtn.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(498, 357);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(286, 5);
            this.panel1.TabIndex = 1046;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(498, 441);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(286, 5);
            this.panel2.TabIndex = 1045;
            // 
            // txtBoxUpdateTotalamount
            // 
            this.txtBoxUpdateTotalamount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxUpdateTotalamount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxUpdateTotalamount.Enabled = false;
            this.txtBoxUpdateTotalamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxUpdateTotalamount.Location = new System.Drawing.Point(498, 441);
            this.txtBoxUpdateTotalamount.MaxLength = 11;
            this.txtBoxUpdateTotalamount.Name = "txtBoxUpdateTotalamount";
            this.txtBoxUpdateTotalamount.Size = new System.Drawing.Size(286, 41);
            this.txtBoxUpdateTotalamount.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(498, 278);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(286, 5);
            this.panel3.TabIndex = 1043;
            // 
            // txtBoxUpdateAccountname
            // 
            this.txtBoxUpdateAccountname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxUpdateAccountname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxUpdateAccountname.Enabled = false;
            this.txtBoxUpdateAccountname.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxUpdateAccountname.Location = new System.Drawing.Point(498, 278);
            this.txtBoxUpdateAccountname.Name = "txtBoxUpdateAccountname";
            this.txtBoxUpdateAccountname.Size = new System.Drawing.Size(286, 41);
            this.txtBoxUpdateAccountname.TabIndex = 6;
            // 
            // dateTimePickerUpdateCreatedate
            // 
            this.dateTimePickerUpdateCreatedate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePickerUpdateCreatedate.CalendarFont = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerUpdateCreatedate.Enabled = false;
            this.dateTimePickerUpdateCreatedate.Font = new System.Drawing.Font("Georgia", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerUpdateCreatedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerUpdateCreatedate.Location = new System.Drawing.Point(498, 357);
            this.dateTimePickerUpdateCreatedate.Name = "dateTimePickerUpdateCreatedate";
            this.dateTimePickerUpdateCreatedate.Size = new System.Drawing.Size(286, 45);
            this.dateTimePickerUpdateCreatedate.TabIndex = 7;
            this.dateTimePickerUpdateCreatedate.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(494, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 24);
            this.label1.TabIndex = 1039;
            this.label1.Text = "Create date:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(494, 414);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 24);
            this.label2.TabIndex = 1041;
            this.label2.Text = "Total Amount:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(494, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 24);
            this.label3.TabIndex = 1038;
            this.label3.Text = "Account name:";
            // 
            // panel20
            // 
            this.panel20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel20.BackColor = System.Drawing.Color.Black;
            this.panel20.Location = new System.Drawing.Point(687, 141);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(132, 7);
            this.panel20.TabIndex = 1037;
            // 
            // panel21
            // 
            this.panel21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel21.BackColor = System.Drawing.Color.Black;
            this.panel21.Location = new System.Drawing.Point(459, 141);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(62, 7);
            this.panel21.TabIndex = 1036;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(523, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(198, 24);
            this.label7.TabIndex = 1035;
            this.label7.Text = "Update and Delete";
            // 
            // panel15
            // 
            this.panel15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel15.BackColor = System.Drawing.Color.Black;
            this.panel15.Location = new System.Drawing.Point(273, 141);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(186, 7);
            this.panel15.TabIndex = 1034;
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(95, 141);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(62, 7);
            this.panel12.TabIndex = 1032;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(815, 141);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(7, 336);
            this.panel6.TabIndex = 1033;
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(458, 141);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(7, 336);
            this.panel9.TabIndex = 1031;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(159, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 24);
            this.label6.TabIndex = 1030;
            this.label6.Text = "Add Account";
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(91, 141);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(7, 336);
            this.panel4.TabIndex = 1029;
            // 
            // panel17
            // 
            this.panel17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Location = new System.Drawing.Point(130, 273);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(286, 5);
            this.panel17.TabIndex = 1028;
            // 
            // panel16
            // 
            this.panel16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Location = new System.Drawing.Point(130, 362);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(286, 5);
            this.panel16.TabIndex = 1027;
            // 
            // txtBoxTotalamount
            // 
            this.txtBoxTotalamount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxTotalamount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxTotalamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTotalamount.Location = new System.Drawing.Point(130, 362);
            this.txtBoxTotalamount.Name = "txtBoxTotalamount";
            this.txtBoxTotalamount.Size = new System.Drawing.Size(286, 41);
            this.txtBoxTotalamount.TabIndex = 4;
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(130, 194);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(286, 5);
            this.panel10.TabIndex = 1023;
            // 
            // txtBoxAccountname
            // 
            this.txtBoxAccountname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxAccountname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxAccountname.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxAccountname.Location = new System.Drawing.Point(130, 194);
            this.txtBoxAccountname.Name = "txtBoxAccountname";
            this.txtBoxAccountname.Size = new System.Drawing.Size(286, 41);
            this.txtBoxAccountname.TabIndex = 2;
            this.txtBoxAccountname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dateTimePickerCreatedate
            // 
            this.dateTimePickerCreatedate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePickerCreatedate.CalendarFont = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerCreatedate.Font = new System.Drawing.Font("Georgia", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerCreatedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerCreatedate.Location = new System.Drawing.Point(130, 273);
            this.dateTimePickerCreatedate.Name = "dateTimePickerCreatedate";
            this.dateTimePickerCreatedate.Size = new System.Drawing.Size(286, 45);
            this.dateTimePickerCreatedate.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(126, 246);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 24);
            this.label11.TabIndex = 1005;
            this.label11.Text = "Create date:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(126, 330);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(160, 24);
            this.label5.TabIndex = 1007;
            this.label5.Text = "Total Amount:";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(126, 162);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(165, 24);
            this.label9.TabIndex = 1003;
            this.label9.Text = "Account name:";
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.Green;
            this.panel5.Location = new System.Drawing.Point(-8, -1);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1021, 5);
            this.panel5.TabIndex = 908;
            // 
            // Add_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1004, 634);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.AddItemGroupBox);
            this.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Add_Account";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Account";
            this.Load += new System.EventHandler(this.Add_Account_Load);
            this.AddItemGroupBox.ResumeLayout(false);
            this.AddItemGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox AddItemGroupBox;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtBoxTotalamount;
        private System.Windows.Forms.DateTimePicker dateTimePickerCreatedate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txtBoxAccountname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtBoxUpdateTotalamount;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtBoxUpdateAccountname;
        private System.Windows.Forms.DateTimePicker dateTimePickerUpdateCreatedate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Updatebtn;
        private System.Windows.Forms.Button Deletebtn;
        private System.Windows.Forms.Button AddNewAccountbtn;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtBoxAccountid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txtBoxSearch;
    }
}