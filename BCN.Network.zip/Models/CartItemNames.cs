﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel;

namespace BCN.Network.Models
{
   public class CartItemNames
    {
        [DisplayName("Item Id")]
        public int ItemID { get; set; }

        [DisplayName("Item Name")]
        public string ItemName { get; set; }
        [DisplayName("Item Price")]

        public decimal ItemPrice { get; set; }
        public int Quantity { get; set; }
        public int Extra { get; set; }
    
        [DisplayName("Total Price")]
        public decimal TotalPrice { get; set; }

        //F5A0EQW-D2D-505DAED7BN
        //private void showReport()
        //{
        //    ReportDocument rdoc = new ReportDocument();
        //    string appPath = Application.StartupPath;
        //    string reportPath = @"Reports\CrystalReport.rpt";
        //    string reportFullPath = Path.Combine(appPath, reportPath);

        //    rdoc.Load(reportFullPath);
        //    crystalReportViewer.ReportSource = rdoc;
        //}


    }
}
