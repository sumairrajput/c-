﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class ManageBankAccount : Form
    {
        public ManageBankAccount()
        {
            InitializeComponent();
        }

        private void pictureBoxAdd_Click(object sender, EventArgs e)
        {

            Mange_User_Account obj = new Mange_User_Account();
            obj.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
            ChangePassword obj = new ChangePassword();
            obj.ShowDialog();
        }

        private void ManageBankAccount_Load(object sender, EventArgs e)
        {

        }

        private void closelbl_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
