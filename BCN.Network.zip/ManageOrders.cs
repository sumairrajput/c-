﻿using BCN.Network.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class ManageOrders : Form
    {
        public ManageOrders()
        {
            InitializeComponent();
        }
        private List<CartItemNames> shoppingCart = new List<CartItemNames>();
      

        

        private void ManageOrders_Load(object sender, EventArgs e)
        {
            LoadAllOrdersIntoDataGridView();
            searchData("");

            //ShowMainScreen("0", false);
            //PrintOrder mf = new PrintOrder();

            //mf.ShowDialog();


        }

        private void LoadAllOrdersIntoDataGridView()
        {
            CartdataGridView.DataSource = GetAllOrders();

        }

        private DataTable GetAllOrders()
        {
            DataTable dtOrders = new DataTable();

            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT [OrderNumber], [TransactionDate], [ClientName],[MobileNo], [TotalAmount], [UserPay], [UserRemaing],[Payment] FROM [Orders]", conn))
                {
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    dtOrders.Load(reader);
                }
            }

            return dtOrders;
        }

        private void CartdataGridView_DoubleClick(object sender, EventArgs e)
        {
            int index = CartdataGridView.Rows.GetFirstRow(DataGridViewElementStates.Selected);
            {
                //if (CartdataGridView.Rows[index].Cells["Payment"].Value.ToString() == "0")
                //{
                    string orderNumber = CartdataGridView.Rows[index].Cells["OrderNumber"].Value.ToString();

                    ShowMainScreen(orderNumber, true);
                //}

            }
           
        }
        private void ShowMainScreen(string orderNumber, bool isUpdate)
        {
            PrintOrder mf = new PrintOrder();
            mf.OrderNumber = orderNumber;
            mf.IsUpdate = isUpdate;
            mf.ShowDialog();

            LoadAllOrdersIntoDataGridView();
        }

     

        private void SearchtextBox_TextChanged(object sender, EventArgs e)
        {
            searchData(SearchtextBox.Text);

        }
        public void searchData(string valueToFind)
        {
            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            string searchQuery = "SELECT * FROM Orders WHERE CONCAT(ClientName,Payment) LIKE '%" + valueToFind + "%'";
            SqlDataAdapter adapter = new SqlDataAdapter(searchQuery, connstring);
            DataTable table = new DataTable();
            adapter.Fill(table);
            CartdataGridView.DataSource = table;

        }

        private void AddOrderBtn_Click(object sender, EventArgs e)
        {
            PrintOrder mf = new PrintOrder();

            mf.ShowDialog();
        }
    }
}
