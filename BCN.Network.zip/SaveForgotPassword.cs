﻿using BCN.Network.Screens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace BCN.Network
{
    public partial class SaveForgotPassword : Form
    {
        string UName = ForgotPassword.to;
        public SaveForgotPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == textBox2.Text)
            {
               

                string connString = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    using (SqlCommand cmd = new SqlCommand("update Login SET [Pwd]='" + textBox2.Text + "' WHERE UName='" + UName + "';", conn))

                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                            MessageBox.Show("Password reset successfully!", "Microsoft Visual Studio Community 2017", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        //Main obj = new Main();
                        //obj.ShowDialog();
                    }
                }
            }
            else
            {
                MessageBox.Show("Password do not match here!","Microsoft Visual Studio Community 2017", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox2.Clear();
                textBox1.Focus();
            }
        }

        private void closelbl_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
