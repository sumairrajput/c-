﻿using System;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using System.Windows.Forms;

namespace BCN.Network
{
    public partial class ShowBankData : Form
    {
        public ShowBankData()
        {
            InitializeComponent();
        }

        private void ShowBankData_Load(object sender, EventArgs e)
        {
            LoadAllOrdersIntoDataGridView();
            searchData("");
        }
        private void LoadAllOrdersIntoDataGridView()
        {
            CartdataGridView.DataSource = GetAllOrders();

        }

        private DataTable GetAllOrders()
        {
            DataTable dtOrders = new DataTable();

            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT [Check Number],[Account Name], [Transaction Date], [Client Name],[Mobile], [CreditorDeposit], [Amount], [Total Balance] FROM [BankAccountDetails]", conn))
                {
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    dtOrders.Load(reader);
                }
            }

            return dtOrders;
        }

       

       

        private void AddOrderBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            Bank_Account ba = new Bank_Account();
            ba.ShowDialog();
        }

        private void SearchtextBox_TextChanged_1(object sender, EventArgs e)
        {
            searchData(SearchtextBox.Text);
        }

        public void searchData(string valueToFind)
        {
            string connstring = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

            string searchQuery = "SELECT * FROM BankAccountDetails WHERE CONCAT([Account Name],[CreditorDeposit],[Transaction Date]) LIKE '%" + valueToFind + "%'";
            SqlDataAdapter adapter = new SqlDataAdapter(searchQuery, connstring);
            DataTable table = new DataTable();
            adapter.Fill(table);
            CartdataGridView.DataSource = table;
            


        }

       

       

       
    }
}
