﻿namespace BCN.Network
{
    partial class Bank_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bank_Account));
            this.PrintPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.PrintDocument = new System.Drawing.Printing.PrintDocument();
            this.ContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.changeExtraChargesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeQuantityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AddItemGroupBox = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtBoxMobileNo = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtBoxCustomerName = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txtBoxOrderId = new System.Windows.Forms.TextBox();
            this.dateTimePickerCustomer = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBoxTotalAmount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.ComboBoxAccountName = new System.Windows.Forms.ComboBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBoxAdd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.unPaidBtn = new System.Windows.Forms.Button();
            this.paidBtn = new System.Windows.Forms.Button();
            this.printOrderBtn = new System.Windows.Forms.Button();
            this.cancleOrderBtn = new System.Windows.Forms.Button();
            this.AddNewOrderbtn = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.ContextMenuStrip.SuspendLayout();
            this.AddItemGroupBox.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PrintPreviewDialog
            // 
            this.PrintPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.PrintPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.PrintPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.PrintPreviewDialog.Enabled = true;
            this.PrintPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("PrintPreviewDialog.Icon")));
            this.PrintPreviewDialog.Name = "PrintPreviewDialog";
            this.PrintPreviewDialog.Visible = false;
            this.PrintPreviewDialog.Load += new System.EventHandler(this.PrintPreviewDialog_Load);
            // 
            // PrintDocument
            // 
            this.PrintDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDocument_PrintPage);
            // 
            // ContextMenuStrip
            // 
            this.ContextMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeExtraChargesToolStripMenuItem,
            this.changeQuantityToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.ContextMenuStrip.Name = "ContextMenuStrip";
            this.ContextMenuStrip.Size = new System.Drawing.Size(223, 76);
            // 
            // changeExtraChargesToolStripMenuItem
            // 
            this.changeExtraChargesToolStripMenuItem.Name = "changeExtraChargesToolStripMenuItem";
            this.changeExtraChargesToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.changeExtraChargesToolStripMenuItem.Text = "&Change Extra Charges";
            // 
            // changeQuantityToolStripMenuItem
            // 
            this.changeQuantityToolStripMenuItem.Name = "changeQuantityToolStripMenuItem";
            this.changeQuantityToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.changeQuantityToolStripMenuItem.Text = "&Change Quantity";
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.deleteToolStripMenuItem.Text = "&Delete";
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.Green;
            this.panel5.Location = new System.Drawing.Point(-8, -1);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1021, 5);
            this.panel5.TabIndex = 907;
            // 
            // AddItemGroupBox
            // 
            this.AddItemGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddItemGroupBox.BackColor = System.Drawing.Color.Silver;
            this.AddItemGroupBox.Controls.Add(this.textBox2);
            this.AddItemGroupBox.Controls.Add(this.checkBox1);
            this.AddItemGroupBox.Controls.Add(this.panel20);
            this.AddItemGroupBox.Controls.Add(this.panel21);
            this.AddItemGroupBox.Controls.Add(this.label7);
            this.AddItemGroupBox.Controls.Add(this.panel15);
            this.AddItemGroupBox.Controls.Add(this.panel12);
            this.AddItemGroupBox.Controls.Add(this.panel6);
            this.AddItemGroupBox.Controls.Add(this.panel9);
            this.AddItemGroupBox.Controls.Add(this.label6);
            this.AddItemGroupBox.Controls.Add(this.panel4);
            this.AddItemGroupBox.Controls.Add(this.panel17);
            this.AddItemGroupBox.Controls.Add(this.panel16);
            this.AddItemGroupBox.Controls.Add(this.txtBoxMobileNo);
            this.AddItemGroupBox.Controls.Add(this.panel13);
            this.AddItemGroupBox.Controls.Add(this.txtBoxCustomerName);
            this.AddItemGroupBox.Controls.Add(this.panel10);
            this.AddItemGroupBox.Controls.Add(this.txtBoxOrderId);
            this.AddItemGroupBox.Controls.Add(this.dateTimePickerCustomer);
            this.AddItemGroupBox.Controls.Add(this.label11);
            this.AddItemGroupBox.Controls.Add(this.panel2);
            this.AddItemGroupBox.Controls.Add(this.label5);
            this.AddItemGroupBox.Controls.Add(this.comboBox);
            this.AddItemGroupBox.Controls.Add(this.label3);
            this.AddItemGroupBox.Controls.Add(this.label10);
            this.AddItemGroupBox.Controls.Add(this.panel8);
            this.AddItemGroupBox.Controls.Add(this.textBoxTotalAmount);
            this.AddItemGroupBox.Controls.Add(this.label9);
            this.AddItemGroupBox.Controls.Add(this.panel11);
            this.AddItemGroupBox.Controls.Add(this.ComboBoxAccountName);
            this.AddItemGroupBox.Controls.Add(this.panel7);
            this.AddItemGroupBox.Controls.Add(this.textBoxAdd);
            this.AddItemGroupBox.Controls.Add(this.label4);
            this.AddItemGroupBox.Controls.Add(this.label2);
            this.AddItemGroupBox.Controls.Add(this.label1);
            this.AddItemGroupBox.Controls.Add(this.textBox1);
            this.AddItemGroupBox.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItemGroupBox.Location = new System.Drawing.Point(14, 15);
            this.AddItemGroupBox.Name = "AddItemGroupBox";
            this.AddItemGroupBox.Size = new System.Drawing.Size(810, 611);
            this.AddItemGroupBox.TabIndex = 906;
            this.AddItemGroupBox.TabStop = false;
            this.AddItemGroupBox.Text = resources.GetString("AddItemGroupBox.Text");
            this.AddItemGroupBox.Enter += new System.EventHandler(this.AddItemGroupBox_Enter);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(294, 314);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(107, 61);
            this.checkBox1.TabIndex = 1038;
            this.checkBox1.Text = "Automatic \r\nFill name \r\nand Mobile";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // panel20
            // 
            this.panel20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel20.BackColor = System.Drawing.Color.Black;
            this.panel20.Location = new System.Drawing.Point(613, 141);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(155, 7);
            this.panel20.TabIndex = 1037;
            // 
            // panel21
            // 
            this.panel21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel21.BackColor = System.Drawing.Color.Black;
            this.panel21.Location = new System.Drawing.Point(408, 141);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(62, 7);
            this.panel21.TabIndex = 1036;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(472, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 24);
            this.label7.TabIndex = 1035;
            this.label7.Text = "Account Details";
            // 
            // panel15
            // 
            this.panel15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel15.BackColor = System.Drawing.Color.Black;
            this.panel15.Location = new System.Drawing.Point(260, 141);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(148, 7);
            this.panel15.TabIndex = 1034;
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(44, 141);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(62, 7);
            this.panel12.TabIndex = 1032;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(764, 141);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(7, 336);
            this.panel6.TabIndex = 1033;
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(407, 141);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(7, 336);
            this.panel9.TabIndex = 1031;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(108, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 24);
            this.label6.TabIndex = 1030;
            this.label6.Text = "Customer Details";
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(40, 141);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(7, 336);
            this.panel4.TabIndex = 1029;
            // 
            // panel17
            // 
            this.panel17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Location = new System.Drawing.Point(79, 432);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(212, 5);
            this.panel17.TabIndex = 1028;
            // 
            // panel16
            // 
            this.panel16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Location = new System.Drawing.Point(79, 357);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(212, 5);
            this.panel16.TabIndex = 1027;
            // 
            // txtBoxMobileNo
            // 
            this.txtBoxMobileNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxMobileNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxMobileNo.Location = new System.Drawing.Point(79, 357);
            this.txtBoxMobileNo.MaxLength = 11;
            this.txtBoxMobileNo.Name = "txtBoxMobileNo";
            this.txtBoxMobileNo.Size = new System.Drawing.Size(212, 41);
            this.txtBoxMobileNo.TabIndex = 1026;
            this.txtBoxMobileNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxMobileNo_KeyPress);
            // 
            // panel13
            // 
            this.panel13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel13.BackColor = System.Drawing.Color.Black;
            this.panel13.Location = new System.Drawing.Point(79, 278);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(212, 5);
            this.panel13.TabIndex = 1025;
            // 
            // txtBoxCustomerName
            // 
            this.txtBoxCustomerName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxCustomerName.Location = new System.Drawing.Point(79, 278);
            this.txtBoxCustomerName.Name = "txtBoxCustomerName";
            this.txtBoxCustomerName.Size = new System.Drawing.Size(212, 41);
            this.txtBoxCustomerName.TabIndex = 1024;
            this.txtBoxCustomerName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxCustomerName_KeyPress);
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(79, 194);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(212, 5);
            this.panel10.TabIndex = 1023;
            // 
            // txtBoxOrderId
            // 
            this.txtBoxOrderId.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBoxOrderId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBoxOrderId.Enabled = false;
            this.txtBoxOrderId.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxOrderId.Location = new System.Drawing.Point(79, 194);
            this.txtBoxOrderId.Name = "txtBoxOrderId";
            this.txtBoxOrderId.Size = new System.Drawing.Size(212, 41);
            this.txtBoxOrderId.TabIndex = 1022;
            this.txtBoxOrderId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dateTimePickerCustomer
            // 
            this.dateTimePickerCustomer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePickerCustomer.CalendarFont = new System.Drawing.Font("Gill Sans Ultra Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerCustomer.Font = new System.Drawing.Font("Georgia", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerCustomer.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerCustomer.Location = new System.Drawing.Point(79, 432);
            this.dateTimePickerCustomer.Name = "dateTimePickerCustomer";
            this.dateTimePickerCustomer.Size = new System.Drawing.Size(212, 45);
            this.dateTimePickerCustomer.TabIndex = 1006;
            this.dateTimePickerCustomer.TabStop = false;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(75, 405);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(183, 24);
            this.label11.TabIndex = 1005;
            this.label11.Text = "Transction Date:";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(442, 274);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(210, 5);
            this.panel2.TabIndex = 1021;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(75, 330);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 24);
            this.label5.TabIndex = 1007;
            this.label5.Text = "Mobile No:";
            // 
            // comboBox
            // 
            this.comboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Amli",
            "Zeera"});
            this.comboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.comboBox.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Items.AddRange(new object[] {
            "Credit",
            "Deposit"});
            this.comboBox.Location = new System.Drawing.Point(442, 273);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(210, 49);
            this.comboBox.TabIndex = 1018;
            this.comboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(438, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 24);
            this.label3.TabIndex = 1019;
            this.label3.Text = "What\'s mind:";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(75, 246);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(143, 24);
            this.label10.TabIndex = 1004;
            this.label10.Text = "Client Name:";
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(442, 432);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(210, 5);
            this.panel8.TabIndex = 1017;
            // 
            // textBoxTotalAmount
            // 
            this.textBoxTotalAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTotalAmount.Enabled = false;
            this.textBoxTotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalAmount.Location = new System.Drawing.Point(442, 432);
            this.textBoxTotalAmount.Name = "textBoxTotalAmount";
            this.textBoxTotalAmount.Size = new System.Drawing.Size(210, 41);
            this.textBoxTotalAmount.TabIndex = 1016;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(75, 162);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 24);
            this.label9.TabIndex = 1003;
            this.label9.Text = "Check Id:";
            // 
            // panel11
            // 
            this.panel11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(442, 190);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(210, 5);
            this.panel11.TabIndex = 1015;
            // 
            // ComboBoxAccountName
            // 
            this.ComboBoxAccountName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ComboBoxAccountName.AutoCompleteCustomSource.AddRange(new string[] {
            "Amli",
            "Zeera"});
            this.ComboBoxAccountName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ComboBoxAccountName.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxAccountName.FormattingEnabled = true;
            this.ComboBoxAccountName.Location = new System.Drawing.Point(442, 189);
            this.ComboBoxAccountName.Name = "ComboBoxAccountName";
            this.ComboBoxAccountName.Size = new System.Drawing.Size(210, 49);
            this.ComboBoxAccountName.TabIndex = 1008;
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(440, 357);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(212, 5);
            this.panel7.TabIndex = 1013;
            // 
            // textBoxAdd
            // 
            this.textBoxAdd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxAdd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAdd.Location = new System.Drawing.Point(440, 357);
            this.textBoxAdd.MaxLength = 20;
            this.textBoxAdd.Name = "textBoxAdd";
            this.textBoxAdd.Size = new System.Drawing.Size(212, 41);
            this.textBoxAdd.TabIndex = 1012;
            this.textBoxAdd.TextChanged += new System.EventHandler(this.textBoxAdd_TextChanged);
            this.textBoxAdd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxMobileNo_KeyPress);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(438, 405);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 24);
            this.label4.TabIndex = 1011;
            this.label4.Text = "Total Amount:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(438, 330);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 24);
            this.label2.TabIndex = 1010;
            this.label2.Text = "What\'s Amount:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(438, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 24);
            this.label1.TabIndex = 1009;
            this.label1.Text = "Select Account:";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(432, 568);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(154, 34);
            this.textBox1.TabIndex = 917;
            this.textBox1.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.unPaidBtn);
            this.panel1.Controls.Add(this.paidBtn);
            this.panel1.Controls.Add(this.printOrderBtn);
            this.panel1.Controls.Add(this.cancleOrderBtn);
            this.panel1.Controls.Add(this.AddNewOrderbtn);
            this.panel1.Location = new System.Drawing.Point(839, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(165, 632);
            this.panel1.TabIndex = 916;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DimGray;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(-9, 81);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(179, 66);
            this.button1.TabIndex = 1038;
            this.button1.Text = "Print Preview";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // unPaidBtn
            // 
            this.unPaidBtn.BackColor = System.Drawing.Color.DimGray;
            this.unPaidBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.unPaidBtn.Enabled = false;
            this.unPaidBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.unPaidBtn.FlatAppearance.BorderSize = 0;
            this.unPaidBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.unPaidBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.unPaidBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unPaidBtn.ForeColor = System.Drawing.Color.White;
            this.unPaidBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.unPaidBtn.Location = new System.Drawing.Point(-7, 423);
            this.unPaidBtn.Name = "unPaidBtn";
            this.unPaidBtn.Size = new System.Drawing.Size(179, 66);
            this.unPaidBtn.TabIndex = 7;
            this.unPaidBtn.Text = "&Deposite";
            this.unPaidBtn.UseVisualStyleBackColor = false;
            this.unPaidBtn.Click += new System.EventHandler(this.unPaidBtn_Click);
            // 
            // paidBtn
            // 
            this.paidBtn.BackColor = System.Drawing.Color.DimGray;
            this.paidBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.paidBtn.Enabled = false;
            this.paidBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.paidBtn.FlatAppearance.BorderSize = 0;
            this.paidBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.paidBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.paidBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paidBtn.ForeColor = System.Drawing.Color.White;
            this.paidBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.paidBtn.Location = new System.Drawing.Point(-7, 353);
            this.paidBtn.Name = "paidBtn";
            this.paidBtn.Size = new System.Drawing.Size(179, 66);
            this.paidBtn.TabIndex = 6;
            this.paidBtn.Text = "&Credit";
            this.paidBtn.UseVisualStyleBackColor = false;
            this.paidBtn.Click += new System.EventHandler(this.paidBtn_Click);
            // 
            // printOrderBtn
            // 
            this.printOrderBtn.BackColor = System.Drawing.Color.DimGray;
            this.printOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.printOrderBtn.Enabled = false;
            this.printOrderBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.printOrderBtn.FlatAppearance.BorderSize = 0;
            this.printOrderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.printOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.printOrderBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printOrderBtn.ForeColor = System.Drawing.Color.White;
            this.printOrderBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.printOrderBtn.Location = new System.Drawing.Point(-8, 283);
            this.printOrderBtn.Name = "printOrderBtn";
            this.printOrderBtn.Size = new System.Drawing.Size(179, 66);
            this.printOrderBtn.TabIndex = 5;
            this.printOrderBtn.Text = "Print Check";
            this.printOrderBtn.UseVisualStyleBackColor = false;
            this.printOrderBtn.Click += new System.EventHandler(this.printOrderBtn_Click);
            // 
            // cancleOrderBtn
            // 
            this.cancleOrderBtn.BackColor = System.Drawing.Color.DimGray;
            this.cancleOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancleOrderBtn.Enabled = false;
            this.cancleOrderBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.cancleOrderBtn.FlatAppearance.BorderSize = 0;
            this.cancleOrderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.cancleOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancleOrderBtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancleOrderBtn.ForeColor = System.Drawing.Color.White;
            this.cancleOrderBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancleOrderBtn.Location = new System.Drawing.Point(-8, 213);
            this.cancleOrderBtn.Name = "cancleOrderBtn";
            this.cancleOrderBtn.Size = new System.Drawing.Size(179, 66);
            this.cancleOrderBtn.TabIndex = 4;
            this.cancleOrderBtn.Text = "Cancle Check";
            this.cancleOrderBtn.UseVisualStyleBackColor = false;
            this.cancleOrderBtn.Click += new System.EventHandler(this.cancleOrderBtn_Click);
            // 
            // AddNewOrderbtn
            // 
            this.AddNewOrderbtn.BackColor = System.Drawing.Color.DimGray;
            this.AddNewOrderbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddNewOrderbtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.AddNewOrderbtn.FlatAppearance.BorderSize = 0;
            this.AddNewOrderbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray;
            this.AddNewOrderbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.AddNewOrderbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddNewOrderbtn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewOrderbtn.ForeColor = System.Drawing.Color.White;
            this.AddNewOrderbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddNewOrderbtn.Location = new System.Drawing.Point(-8, 143);
            this.AddNewOrderbtn.Name = "AddNewOrderbtn";
            this.AddNewOrderbtn.Size = new System.Drawing.Size(179, 66);
            this.AddNewOrderbtn.TabIndex = 111;
            this.AddNewOrderbtn.Text = "New Check";
            this.AddNewOrderbtn.UseVisualStyleBackColor = false;
            this.AddNewOrderbtn.Click += new System.EventHandler(this.AddNewOrderbtn_Click);
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(260, 568);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(154, 34);
            this.textBox2.TabIndex = 1039;
            // 
            // Bank_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1004, 634);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.AddItemGroupBox);
            this.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Bank_Account";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bank Account";
            this.Load += new System.EventHandler(this.Bank_Account_Load);
            this.ContextMenuStrip.ResumeLayout(false);
            this.AddItemGroupBox.ResumeLayout(false);
            this.AddItemGroupBox.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PrintPreviewDialog PrintPreviewDialog;
        private System.Drawing.Printing.PrintDocument PrintDocument;
        private System.Windows.Forms.ContextMenuStrip ContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem changeExtraChargesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeQuantityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox AddItemGroupBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button paidBtn;
        private System.Windows.Forms.Button printOrderBtn;
        private System.Windows.Forms.Button cancleOrderBtn;
        private System.Windows.Forms.Button AddNewOrderbtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button unPaidBtn;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtBoxMobileNo;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtBoxCustomerName;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txtBoxOrderId;
        private System.Windows.Forms.DateTimePicker dateTimePickerCustomer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBoxTotalAmount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.ComboBox ComboBoxAccountName;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBoxAdd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}