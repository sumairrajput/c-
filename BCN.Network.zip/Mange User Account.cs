﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Data.SqlClient;

namespace BCN.Network
{
    public partial class Mange_User_Account : Form
    {
        public Mange_User_Account()
        {
            InitializeComponent();
        }
        void reset()
        {
            textBox1.Clear();
            textBox3.Clear();
            textBox4.Clear();

            //textBox1.Enabled = false;
            textBox3.Enabled = false;
        }

        private void Mange_User_Account_Load(object sender, EventArgs e)
        {

        }

        private void closelbl_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     

       

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (textBox4.Text == "")
                {
                    reset();
                    textBox4.Focus();

                }
                else
                {
                    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
                    using (SqlConnection cnn = new SqlConnection(st))
                    {

                        SqlCommand cmm = new SqlCommand("select * from Login where  UName=@find", cnn);
                        cnn.Open();
                        SqlDataReader rdr;
                        cmm.Parameters.Add("@find", SqlDbType.VarChar, 50, "UName");
                        cmm.Parameters["@find"].Value = textBox4.Text;
                        rdr = cmm.ExecuteReader();
                        while (rdr.Read())

                        {
                            textBox1.Text = rdr[0].ToString();
                            textBox3.Text = rdr[1].ToString();


                            //textBox1.Enabled = true;
                            textBox3.Enabled = true;
                           

                        }
                        cnn.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox4.Text == "")
                {
                    MessageBox.Show("No data found here!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    textBox4.Focus();

                }
                else
                {
                    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
                    using (SqlConnection cnn = new SqlConnection(st))
                    {
                        SqlCommand cmm = new SqlCommand("update Login  set [UName]='" + textBox3.Text + "' where ID='" + textBox1.Text + "';", cnn);

                        cnn.Open();


                        cmm.ExecuteNonQuery();
                        MessageBox.Show("Data is Updated...Successful!", "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        cnn.Close();
                        reset();
                        textBox4.Focus();
                    }

                }
            }

            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
        }
    }
}
