﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BCN.Network
{
    public partial class Add_Account : Form
    {
        public Add_Account()
        {
            InitializeComponent();
        }
        void reset()
        {
            txtBoxAccountid.Clear();
            txtBoxUpdateAccountname.Clear();
            dateTimePickerUpdateCreatedate.Text="";
            txtBoxUpdateTotalamount.Clear();

            Updatebtn.Enabled = false;
            Deletebtn.Enabled = false;
            txtBoxUpdateAccountname.Enabled = false;
            dateTimePickerUpdateCreatedate.Enabled = false;
            txtBoxUpdateTotalamount.Enabled = false;
        }

        private void Add_Account_Load(object sender, EventArgs e)
        {
            txtBoxSearch.Focus();
        }

        private void AddItemGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void txtBoxSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtBoxSearch.Text == "")
                {
                    reset();
                    txtBoxSearch.Focus();

                }
                else
                {
                    string st = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
                    using (SqlConnection cnn = new SqlConnection(st))
                    {

                        SqlCommand cmm = new SqlCommand("select * from BankAccount where  AccountName=@find", cnn);
                        cnn.Open();
                        SqlDataReader rdr;
                        cmm.Parameters.Add("@find", SqlDbType.VarChar, 50, "AccountName");
                        cmm.Parameters["@find"].Value = txtBoxSearch.Text;
                        rdr = cmm.ExecuteReader();
                        while (rdr.Read())

                        {
                            txtBoxAccountid.Text = rdr[0].ToString();
                            txtBoxUpdateAccountname.Text = rdr[1].ToString();
                            dateTimePickerUpdateCreatedate.Text = rdr[2].ToString();
                            txtBoxUpdateTotalamount.Text = rdr[3].ToString();

                            Updatebtn.Enabled = true;
                            Deletebtn.Enabled = true;
                            txtBoxUpdateAccountname.Enabled = true;
                            dateTimePickerUpdateCreatedate.Enabled = true;
                            txtBoxUpdateTotalamount.Enabled = true;


                        }
                        cnn.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Keryana Store", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
