﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using BCN.Network.Screens;

namespace BCN.Network
{
    public partial class ForgotPassword : Form
    {

        string randomCode;
        public static string to;
        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (randomCode == (textBox2.Text).ToString())
            {
                to = textBox1.Text;
                this.Hide();
                SaveForgotPassword obj = new SaveForgotPassword();
                obj.ShowDialog();
            }
            else
            {
                            MessageBox.Show("Enter wrong code here, Please check your e-mail carefully!", "Microsoft Visual Studio Community 2017", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          ;
        }

        private void ForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            //if (IsValidated()) { 
            string from, pass, messageBody;
            Random rand = new Random();
            randomCode = (rand.Next(999999)).ToString();
            MailMessage message = new MailMessage();
            to = (textBox1.Text).ToString();
            from = "sumairrajput465@gmail.com";
            pass = "sumair786,.";
            messageBody = "Your reset code is: " + randomCode;
            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = messageBody;
            message.Subject = "Welcome to -> Password reseting code:";
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(from, pass);
            try
            {
                smtp.Send(message);
                            MessageBox.Show("Code send successfully, Please check your e-mail here!", "Microsoft Visual Studio Community 2017", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox2.Enabled = true;
                textBox2.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //}
        }

        private void closelbl_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

        private void textBox1_Leave(object sender, EventArgs e)
        {


            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(textBox1.Text, pattern))
            {
                //MessageBox.Show("Yes");
            }
            else
            {
                MessageBox.Show("Please enter valid e-mail address","Keryana Store",MessageBoxButtons.OK,MessageBoxIcon.Error);
                textBox1.Focus();
            }
                

        }
    }
}
